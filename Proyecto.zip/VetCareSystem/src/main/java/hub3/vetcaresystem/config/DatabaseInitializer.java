/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.config;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author coder
 */
public class DatabaseInitializer {
    
    public static void iitializerDataBase(){
          String sql = """
                       -- Tabla de Propetarios (owners)
                       Create TABLE IF NO EXIST owners(
                       id INT AUTO_INCREMENT PRIMARE KEY,
                       tipo_identificacion VATCHAR (20) NOT NULL,
                       numero_identificacion VATCHAT(50) UNIQUE NOT NULL,
                       nombre_completo VARCHAR(100) NOT NULL,
                       telefono VARCHAR(20) NOT NULL,
                       correo_electronico VARCHAR(100) UNIQUE,
                       direccion VARCHAR(150),
                       estado BOOLEAN DEFALUT TRUE,
                       fecha_registro DATE NOT NULL
                       );
                       
                       --Tabla de Mascotas (pets) 
                       CREATE TALE IF NOT EXIST pets(
                       id INT AUTO_INCREMENT PRIMARY KEY,
                       nombre VARCHAR(50) NOT NULL,
                       especie VARCHAR(50) NOT NULL, 
                       raza VARCHAR(50),
                       sexo VARCHAR(20),
                       fecha_nacimineto DATE,
                       peso DECIMAL(5, 2),
                       owner_id INT NOT NULL,
                       estado BOOLEAN DEFAULT TRUE,
                       fecha_registro DATE NOT NULL,
                       FOREING KEY (owner_id) REFERENCES owners(id)
                       );
                       
                       """;
          
          try (Connection conn = DatabaseConnection.getConnection();
                  Statement stmt = conn.createStatement()) {
              
              stmt.execute(sql);
              System.out.println("Base de datos inicializada correctamente con H2.");
              
           } catch (SQLException e){
                System.err.println("Error al inicializar la base de datos: " + e.getMessage());
           }
    }

    public static void initializeDatabase() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
