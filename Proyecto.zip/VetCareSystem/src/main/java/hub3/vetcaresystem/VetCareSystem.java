/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package hub3.vetcaresystem;

import hub3.vetcaresystem.config.DatabaseInitializer;

/**
 *
 * @author coder
 */
public class VetCareSystem {

    public static void main(String[] args) {
        DatabaseInitializer.initializeDatabase();
        
        System.out.println("!Bienvenido al sistema Vetcare!");
               
    }
}
