/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.model;

import java.time.LocalDate;

/**
 *
 * @author coder
 */
public class Mascota {
    
    private int id;
    private String nombre;
    private String especie;
    private String raza;
    private String sexo;
    private LocalDate fechaNacimiento;
    private double peso;
    private Propietario propietario; // Aquí aplicamos la relación entre clases
    private boolean estado; // true para activo, false para inactivo
    private LocalDate fechaRegistro;

    public Mascota(int id, String nombre, String especie, String raza, String sexo, LocalDate fechaNacimiento, double peso, Propietario propietario, boolean estado, LocalDate fechaRegistro) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.sexo = sexo;
        this.fechaNacimiento = fechaNacimiento;
        this.peso = peso;
        this.propietario = propietario;
        this.estado = estado;
        this.fechaRegistro = fechaRegistro;
    }
    
    //Getters

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public String getRaza() {
        return raza;
    }

    public String getSexo() {
        return sexo;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public double getPeso() {
        return peso;
    }

    public Propietario getPropietario() {
        return propietario;
    }

    public boolean isEstado() {
        return estado;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }
    
    //Setters 
    
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
    
    @Override 
    public String toString() {
        return nombre + " (" +especie+" ) - Dueño: " + (propietario != null ? propietario.getNombreCompleto() : "Sin asignar"); 
    }
    
}
