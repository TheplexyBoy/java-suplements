/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.vetcaresystem.dao;

import hub3.vetcaresystem.model.Propietario;
import java.util.List;

/**
 *
 * @author coder
 */
public interface PropietarioDAO {
    void guardar(Propietario propietario);
    
    Propietario buscarPorIdentificacion(String identificacion);
    
    List<Propietario> listarTodos();
    
    void actualizar(Propietario propietario);
    
    void eliminar(int id);
}
