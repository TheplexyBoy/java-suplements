/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.dao;

import hub3.vetcaresystem.config.DatabaseConnection;
import hub3.vetcaresystem.model.Propietario;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author coder
 */
public class PropietarioDAOImpl implements PropietarioDAO {
    
    @Override 
    public void guardar(Propietario propietario) {
         String sql = "INSERT INTO owners (tipo_identificacion, numero_identificacion, nombre_completo, telefono, correo_electronico, direccion, estado, fecha_registro) VALUES (?, ?, ?, ?, ?, ?, ?, ?";
    
    try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        stmt.setString(1, propietario.getTipoIdentificacion());
        stmt.setString(2, propietario.getNumeroIdentificacion());
        stmt.setString(3, propietario.getNombreCompleto());
        stmt.setString(4, propietario.getTelefono());
        stmt.setString(5, propietario.getCorreoElectronico());
        stmt.setString(6, propietario.getDireccion());
        stmt.setBoolean(7, propietario.isEstado());
        stmt.setDate(8, Date.valueOf(propietario.getFechaRegistro()));
        
        stmt.executeUpdate(); // Ejecuta la insercion a la base de datos
        
    } catch (SQLException e) { 
        System.err.println("Error al guardar propietario: " + e.getMessage());
    }
         
    }
}
