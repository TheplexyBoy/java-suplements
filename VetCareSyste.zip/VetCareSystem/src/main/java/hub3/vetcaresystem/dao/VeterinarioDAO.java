/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.vetcaresystem.dao;

import hub3.vetcaresystem.model.Veterinario;
import java.util.List;

/**
 *
 * @author coder
 */
public interface VeterinarioDAO {
    void registrar(Veterinario veterinario);
    
    List<Veterinario> listarTodos();
    
    Veterinario buscarPorId(int id);
    
    void actualizar(Veterinario veterinario);
    
    void inactivar(int id);
    
    List<Veterinario> buscarPorEspecialidad(String especialidad);
    
    
}
