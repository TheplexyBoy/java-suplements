package hub3.vetcaresystem.dao;

import hub3.vetcaresystem.model.Propietario;
import java.util.List;

public interface PropietarioDAO {
    
    void registrar(Propietario propietario);
    
    List<Propietario> listarTodos();
    
    Propietario buscarPorId(int id);
    
    void actualizar(Propietario propietario);
    
    // Método para activar o desactivar al propietario (eliminación lógica)
    void cambiarEstado(int id); 
    
    // Método extra útil según tus requerimientos: Buscar por número de documento
    Propietario buscarPorIdentificacion(String numeroIdentificacion);
}