package hub3.vetcaresystem.dao.impl;

import hub3.vetcaresystem.config.DatabaseConnection;
import hub3.vetcaresystem.dao.PropietarioDAO;
import hub3.vetcaresystem.model.Propietario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PropietarioDAOImpl implements PropietarioDAO {

    @Override
    public void registrar(Propietario propietario) {
        // 1. Armamos el SQL con las columnas exactas que vas a tener en pgAdmin
        // Nota: Omitimos el 'id' y 'fechaRegistro' porque la base de datos los genera solita (con SERIAL y DEFAULT CURRENT_DATE)
        String sql = "INSERT INTO propietarios (tipo_identificacion, numero_identificacion, nombre_completo, correo_electronico, telefono, direccion, estado) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)){
            
            // 2. El mensajero "abre tu caja" (el modelo) y saca los datos uno por uno
            stmt.setString(1, propietario.getTipoIdentificacion());
            stmt.setString(2, propietario.getNumeroIdentificacion());
            stmt.setString(3, propietario.getNombreCompleto()); // Usando TU nombre de variable
            stmt.setString(4, propietario.getCorreoElectronico());
            stmt.setString(5, propietario.getTelefono());
            stmt.setString(6, propietario.getDireccion());
            stmt.setBoolean(7, propietario.isEstado()); // Usando boolean
            
            // 3. Envía el paquete a pgAdmin
            stmt.executeUpdate();
            System.out.println("¡BINGO! Propietario guardado exitosamente.");
            
        } catch (SQLException e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }

    // ... (resto de métodos vacíos) ...

    @Override
    public List<Propietario> listarTodos() {
        
        List<Propietario> listaPropietarios = new ArrayList<>();
        
        String sql = "SELECT * FROM propietarios";
        
        try (Connection conn = DatabaseConnection.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
                 
                 while (rs.next()) {
                     
                     Propietario p = new Propietario();
                     
                     p.setId(rs.getInt("id"));
                     p.setTipoIdentificacion(rs.getString("tipo_identificacion"));
                     p.setNombreCompleto(rs.getString("nombre_completo"));
                     p.setCorreoElectronico(rs.getString("correo_electronico"));
                     p.setTelefono(rs.getString("telefono"));
                     p.setDireccion(rs.getString("direcion"));
                     p.setEstado(rs.getBoolean("estado"));
                 
                     listaPropietarios.add(p);
                 }
                 
                 
             }catch (SQLException e) {
                     System.out.println("Error al listar propietarios: " + e.getMessage());
                     }
            
            return listaPropietarios;
    }

    @Override
    public Propietario buscarPorId(int id) {
        
        Propietario propietarioEncontrado = null;
        
        String sql = "SELECT * FROM propietarios WHERE id = ?";
        
        try(Connection conn = DatabaseConnection.obtenerConexion();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
        
            stmt.setInt(1, id);
        
            try(ResultSet rs = stmt.executeQuery()) {

                if(rs.next()) {
                    propietarioEncontrado = new Propietario();

                    propietarioEncontrado.setId(rs.getInt("id"));
                    propietarioEncontrado.setTipoIdentificacion(rs.getString("tipo_identificacion"));
                    propietarioEncontrado.setNumeroIdentificacion(rs.getString("numero_identificacion"));
                    propietarioEncontrado.setNombreCompleto(rs.getString("nombre_completo"));
                    propietarioEncontrado.setCorreoElectronico(rs.getString("correo_electronico"));
                    propietarioEncontrado.setTelefono(rs.getString("telefono"));
                    propietarioEncontrado.setDireccion(rs.getString("direccion"));
                    propietarioEncontrado.setEstado(rs.getBoolean("estado"));
                }
            } 
            }catch (SQLException e) {
                System.out.println("Error al buscar por ID: " + e.getMessage());    
            
        }
        
        return propietarioEncontrado;
    }

    @Override
    public void actualizar(Propietario propietario) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void cambiarEstado(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Propietario buscarPorIdentificacion(String numeroIdentificacion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}