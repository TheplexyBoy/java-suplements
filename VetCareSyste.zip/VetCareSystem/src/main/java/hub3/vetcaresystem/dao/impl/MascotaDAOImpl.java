package hub3.vetcaresystem.dao.impl;

import hub3.vetcaresystem.config.DatabaseConnection;
import hub3.vetcaresystem.dao.MascotaDAO;
import hub3.vetcaresystem.model.Mascota;
import hub3.vetcaresystem.model.Propietario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MascotaDAOImpl implements MascotaDAO {

    @Override
    public void registrar(Mascota mascota) {
        String sql = "INSERT INTO mascotas (nombre, especie, raza, sexo, fecha_nacimiento, peso, id_propietario, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, mascota.getNombre());
            stmt.setString(2, mascota.getEspecie());
            stmt.setString(3, mascota.getRaza());
            stmt.setString(4, mascota.getSexo());
            
            if (mascota.getFechaNacimiento() != null) {
                stmt.setDate(5, java.sql.Date.valueOf(mascota.getFechaNacimiento()));
            } else {
                stmt.setNull(5, java.sql.Types.DATE);
            }
            
            stmt.setDouble(6, mascota.getPeso());
            stmt.setInt(7, mascota.getPropietario().getId());
            stmt.setBoolean(8, mascota.isEstado());
            
            stmt.executeUpdate();
            System.out.println("¡Mascota registrada exitosamente!");
            
        } catch (SQLException e) {
            System.out.println("Error al registrar mascota: " + e.getMessage());
        }
    }

    @Override
    public List<Mascota> listarTodas() {
        List<Mascota> lista = new ArrayList<>();
        String sql = "SELECT * FROM mascotas";
        
        try (Connection conn = DatabaseConnection.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Mascota m = new Mascota();
                m.setId(rs.getInt("id"));
                m.setNombre(rs.getString("nombre"));
                m.setEspecie(rs.getString("especie"));
                m.setRaza(rs.getString("raza"));
                m.setSexo(rs.getString("sexo"));
                
                // CONCEPTO NUEVO: Convertir Date de SQL a LocalDate de Java
                if (rs.getDate("fecha_nacimiento") != null) {
                    m.setFechaNacimiento(rs.getDate("fecha_nacimiento").toLocalDate());
                }
                
                m.setPeso(rs.getDouble("peso"));
                m.setEstado(rs.getBoolean("estado"));
                
                // CONCEPTO NUEVO: Reconstruir la Llave Foránea.
                // Como nuestra Mascota necesita una "caja" de Propietario, 
                // creamos una cajita rápida, le ponemos el ID que viene de la base de datos, 
                // y la guardamos dentro de la mascota.
                Propietario p = new Propietario();
                p.setId(rs.getInt("id_propietario"));
                m.setPropietario(p);
                
                lista.add(m);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar mascotas: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public void actualizar(Mascota mascota) {
        // CONCEPTO NUEVO: UPDATE. 
        // Sirve para modificar datos que ya existen. 
        // ¡OJO! Siempre debe llevar el WHERE id = ?, si no, ¡le cambiarás el nombre a todas las mascotas de la base de datos!
        String sql = "UPDATE mascotas SET nombre=?, especie=?, raza=?, sexo=?, fecha_nacimiento=?, peso=?, id_propietario=?, estado=? WHERE id=?";
        
        try (Connection conn = DatabaseConnection.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, mascota.getNombre());
            stmt.setString(2, mascota.getEspecie());
            stmt.setString(3, mascota.getRaza());
            stmt.setString(4, mascota.getSexo());
            
            if (mascota.getFechaNacimiento() != null) {
                stmt.setDate(5, java.sql.Date.valueOf(mascota.getFechaNacimiento()));
            } else {
                stmt.setNull(5, java.sql.Types.DATE);
            }
            
            stmt.setDouble(6, mascota.getPeso());
            stmt.setInt(7, mascota.getPropietario().getId());
            stmt.setBoolean(8, mascota.isEstado());
            
            // Este es el comodín número 9, el que va en el WHERE id=?
            stmt.setInt(9, mascota.getId());
            
            stmt.executeUpdate();
            System.out.println("¡Mascota actualizada exitosamente!");
            
        } catch (SQLException e) {
            System.out.println("Error al actualizar mascota: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(int id) {
        // CONCEPTO NUEVO: DELETE. 
        // Borra una fila completa. Igual que el UPDATE, NUNCA olvides el WHERE.
        String sql = "DELETE FROM mascotas WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("¡Mascota eliminada de la base de datos!");
            
        } catch (SQLException e) {
            System.out.println("Error al eliminar mascota: " + e.getMessage());
        }
    }

    @Override
    public List<Mascota> buscarPorNombre(String nombreMascota) {
        List<Mascota> lista = new ArrayList<>();
        // CONCEPTO NUEVO: ILIKE (o LIKE).
        // En lugar de buscar un nombre EXACTO (ej. "Firulais"), busca coincidencias.
        // Si buscas "Firu", te traerá a "Firulais". (ILIKE es para que ignore mayúsculas y minúsculas en PostgreSQL).
        String sql = "SELECT * FROM mascotas WHERE nombre ILIKE ?";
        
        try (Connection conn = DatabaseConnection.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // CONCEPTO NUEVO: Los % son comodines de SQL que significan "cualquier texto antes o después"
            stmt.setString(1, "%" + nombreMascota + "%");
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Mascota m = new Mascota();
                    m.setId(rs.getInt("id"));
                    m.setNombre(rs.getString("nombre"));
                    m.setEspecie(rs.getString("especie"));
                    // (Para no hacer el código gigante, aquí puedes llenar los demás setters igual que en listarTodas)
                    lista.add(m);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar por nombre: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public List<Mascota> buscarPorIdentificacionPropietario(String cedula) {
        List<Mascota> lista = new ArrayList<>();
        
        // CONCEPTO NUEVO: INNER JOIN.
        // Es la habilidad más importante en SQL. Sirve para cruzar dos tablas.
        // Le estamos diciendo: "Tráeme las mascotas (m), pero crúzalas con los propietarios (p) 
        // donde el ID coincida, para yo poder filtrar usando la cédula del dueño".
        String sql = "SELECT m.* FROM mascotas m INNER JOIN propietarios p ON m.id_propietario = p.id WHERE p.numero_identificacion = ?";
        
        try (Connection conn = DatabaseConnection.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cedula);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Mascota m = new Mascota();
                    m.setId(rs.getInt("id"));
                    m.setNombre(rs.getString("nombre"));
                    m.setEspecie(rs.getString("especie"));
                    // (Aquí también llenaríamos los demás campos)
                    lista.add(m);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar mascotas del propietario: " + e.getMessage());
        }
        return lista;
    }
}