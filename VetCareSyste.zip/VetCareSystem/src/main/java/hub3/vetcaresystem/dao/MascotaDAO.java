/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.vetcaresystem.dao;

import hub3.vetcaresystem.model.Mascota;
import java.util.List;

/**
 *
 * @author coder
 */
public interface MascotaDAO {
    void registrar(Mascota mascota);
        
    List<Mascota> listarTodas();
    
    void actualizar(Mascota mascota);
    
    void eliminar(int id);
    
    List<Mascota> buscarPorNombre(String nombreMascota);
    
    List<Mascota> buscarPorIdentificacionPropietario(String cedula);
}



