/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.vetcaresystem.dao;

import hub3.vetcaresystem.model.Medicamento;
import java.util.List;

/**
 *
 * @author coder
 */
public interface MedicamentoDAO {
    
    void registrar(Medicamento medicamento);
    
    Medicamento buscarPorId(int id);
    
    List<Medicamento> listarTodos();
    
    List<Medicamento> buscarPorNombre(String nombreMedicamento);
    
    void actualizar(Medicamento medicamento);
    
    void cambiarEstado(int id);
    
    List<Medicamento> listarBajoStock (int stockMinimo);
    
    
}
