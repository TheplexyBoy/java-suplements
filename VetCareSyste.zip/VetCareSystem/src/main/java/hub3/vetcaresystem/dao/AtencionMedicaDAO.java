/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.vetcaresystem.dao;

import hub3.vetcaresystem.model.AtencionMedica;
import java.util.List;

/**
 *
 * @author coder
 */
public interface AtencionMedicaDAO {
    
    void iniciarAtencion(AtencionMedica atencionMedica);
    
    void registrarAtencionMedica(int id, String registrarSintoma, String registrarDiagnostico, String registrarObservaciones, String registrarTratamiento);
    
    void cantidadDeMedicamentoUsada(int idAtencion, int idMedicamento, int cantidad);
    
    void finalizarAtencion(int id);
    
    List<AtencionMedica> atencionesPorMascota(int idMascota);
   
    List<AtencionMedica> listarTodas();

    
    
}
