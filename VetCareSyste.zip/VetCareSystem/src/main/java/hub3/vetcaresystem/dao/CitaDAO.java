/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.vetcaresystem.dao;

import hub3.vetcaresystem.model.Cita;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author coder
 */
public interface CitaDAO {
    
    void registrar(Cita cita);
    
    void actualizar(Cita cita);
    
    Cita consultarCita(int id);
    
    List<Cita> listarTodas();
    
    void cancelarCita(int id);
    
    List<Cita> consultarEstado(String estado);
    void cambiarEstado(int id, String nuevoEstado);
    
    
    List<Cita> consultarCitaPorMascota(int idMascota);
    List<Cita> consultarCitaPorVeterinario(int idVeterinario);
    List<Cita> consultarCitaPorFecha(LocalDateTime fecha);
    
    
    
}
