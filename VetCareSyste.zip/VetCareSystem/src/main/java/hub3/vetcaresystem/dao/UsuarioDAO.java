/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package hub3.vetcaresystem.dao;

import hub3.vetcaresystem.model.Usuario;
import java.util.List;

/**
 *
 * @author Andres
 */
public interface UsuarioDAO {
    
    Usuario autenticar(String username, String passoword);
    
    
    void registrar (Usuario usuario);
    void actualizar (Usuario usuario);
    
    List<Usuario> listarTodos();
    
    Usuario buscarPorId(int id);
    
    void cambiarEstado(int id);
}
