/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author coder
 */
public class DatabaseConnection {
    
// PostgreSQL usa el puerto 5432 por defecto
    private static final String URL = "jdbc:postgresql://localhost:5432/vetcare_db";
    
    // En Postgres, el usuario maestro casi siempre se llama "postgres"
    private static final String USER = "postgres"; 
    
    // Aquí pon la clave que te pide pgAdmin cuando lo abres
    private static final String PASSWORD = "12345"; 

    public static Connection obtenerConexion() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error fatal al conectar con PostgreSQL: " + e.getMessage());
            return null;
        }
    }
}
