/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package hub3.vetcaresystem;

import hub3.vetcaresystem.dao.PropietarioDAO;
import hub3.vetcaresystem.dao.impl.PropietarioDAOImpl;
import hub3.vetcaresystem.model.Propietario;

/**
 *
 * @author coder
 */


public class VetCareSystem {
public static void main(String[] args) {
        
        // 1. Instanciamos tu modelo exacto
        Propietario p = new Propietario();
        p.setId(1);
        p.setTipoIdentificacion("CC");
        p.setNumeroIdentificacion("1020304050");
        p.setNombreCompleto("Andres Quintero");
        p.setCorreoElectronico("andres@email.com");
        p.setTelefono("3001234567");
        p.setDireccion("Calle Falsa 123");
        p.setEstado(true);
        
        // 2. Llamamos al mensajero
        PropietarioDAO dao = new PropietarioDAOImpl();
        dao.registrar(p);
    }
}

