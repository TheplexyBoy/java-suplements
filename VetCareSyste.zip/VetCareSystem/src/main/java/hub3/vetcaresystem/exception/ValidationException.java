/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.exception;

/**
 *
 * @author coder
 */
public class ValidationException extends Exception {
    
    public ValidationException(String mensaje) {
        super(mensaje);
    }
}
