/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.model;

import java.time.LocalDateTime;

/**
 *
 * @author coder
 */
public class Medicamento {
       
    private int id;
    private String codigo;
    private String nombre;
    private String presentacion;
    private String laboratorio;
    private int cantidadDisponible;
    private int cantidadMinima;
    private double precioUnitario;
    private String estado;
    private LocalDateTime fechaRegistro;
    
    public Medicamento() { 
        this.fechaRegistro = LocalDateTime.now();
    }

    public Medicamento(int id, String codigo, String nombre, String presentacion, String laboratorio, int cantidadDisponible, int cantidadMinina, double precioUnitario, String estado, LocalDateTime fechaRegistro) {
        this.id = id;
        this.codigo = codigo;
        this.nombre = nombre;
        this.presentacion = presentacion;
        this.laboratorio = laboratorio;
        this.cantidadDisponible = cantidadDisponible;
        this.cantidadMinima = cantidadMinina;
        this.precioUnitario = precioUnitario;
        this.estado = estado;
        this.fechaRegistro = fechaRegistro;
    }
    
    //Getters 
    
    public int getId() {
        return id;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPresentacion() {
        return presentacion;
    }

    public String getLaboratorio() {
        return laboratorio;
    }

    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    public int getCantidadMinina() {
        return cantidadMinima;
    }

    public double PrecioUnitario() {
        return precioUnitario;
    }

    public String getEstado() {
        return estado;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }
    
    //Setters

    public void setId(int id) {
        this.id = id;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPresentacion(String presentacion) {
        this.presentacion = presentacion;
    }

    public void setLaboratorio(String laboratorio) {
        this.laboratorio = laboratorio;
    }

    public void setCantidadDisponible(int cantidadDisponible) {
        this.cantidadDisponible = cantidadDisponible;
    }

    public void setCantidadMinina(int cantidadMinina) {
        this.cantidadMinima = cantidadMinina;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setFechaRegistro(LocalDateTime fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
    
    @Override
    public String toString() { 
        String Mostrarcodigo = (this.codigo != null && this.codigo.trim().isEmpty()) ? this.codigo : "Sin codigo";
        
        return Mostrarcodigo + " - " + nombre + " (" + laboratorio + ") | Stock: " + cantidadDisponible + " | $"+precioUnitario;
    }
    
    
}
