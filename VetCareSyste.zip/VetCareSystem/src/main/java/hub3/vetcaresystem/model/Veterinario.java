/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.model;

/**
 *
 * @author coder
 */
public class Veterinario {
    
    private int id;
    private String numeroDocumento;
    private String nombre;
    private String tarjetaProfesional;
    private String especialidad;
    private String telefono;
    private String correoElectronico;
    private Boolean estado;

    public Veterinario(int id, String numeroDocumento, String nombre, String tarjetaProfesional, String especialidad, String telefono, String correoElectronico, Boolean estado) {
        this.id = id;
        this.numeroDocumento = numeroDocumento;
        this.nombre = nombre;
        this.tarjetaProfesional = tarjetaProfesional;
        this.especialidad = especialidad;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.estado = estado;
    }
    
    //Getters

    public int getId() {
        return id;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTarjetaProfesional() {
        return tarjetaProfesional;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public Boolean getEstado() {
        return estado;
    }

    //Setters
    
    public void setId(int id) {
        this.id = id;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTarjetaProfesional(String tarjetaProfesional) {
        this.tarjetaProfesional = tarjetaProfesional;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }
    
    @Override
    public String toString(){
        return nombre + " - Especialidad " + especialidad;
    }   
}
 