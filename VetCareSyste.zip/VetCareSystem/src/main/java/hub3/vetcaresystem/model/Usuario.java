/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.model;

/**
 *
 * @author coder
 */
public class Usuario {

    private int id;
    private String username;
    private String password;
    private String rol;
    private boolean estado;
    
    public Usuario() { 
        
    }

    public Usuario(int id, String username, String password, String rol, boolean estado) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.rol = rol;
        this.estado = estado;
    }
    
    //Getters

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getRol() {
        return rol;
    }

    public boolean getEstado() {
        return estado;
    }
    
    //Setters

    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String usarname) {
        this.username = usarname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
    @Override
    public String toString(){
        String mostrarUsername = (this.username != null && !this.username.trim().isEmpty()) ? this.username : "Sin credenciales";
        String textoEstado = (this.estado) ?  "Activo " : "Inactivo";
        
        return "Usernmae: "+ mostrarUsername + " | Rol: " + rol + " | Estado: "+textoEstado; 
    }
    
    
    
}
