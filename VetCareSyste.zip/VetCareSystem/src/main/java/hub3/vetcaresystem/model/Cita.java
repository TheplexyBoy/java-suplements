/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 *
 * @author coder
 */
public class Cita {
    
    private int id;
    private Mascota mascota;
    private Veterinario veterinario;
    private LocalDate fecha;
    private LocalTime hora;
    private String motivo;
    private String estado;
    private LocalDateTime fechaDeCreacion;

    public Cita() {
        this.fechaDeCreacion = LocalDateTime.now();
    }
     
    public Cita(int id, Mascota mascota, Veterinario veterinario, LocalDate fecha, LocalTime hora, String motivo, String estado, LocalDateTime fechaDeCreacion) {
        this.id = id;
        this.mascota = mascota;
        this.veterinario = veterinario;
        this.fecha = fecha;
        this.hora = hora;
        this.motivo = motivo;
        this.estado = estado;
        this.fechaDeCreacion = LocalDateTime.now();
    }
    
    //Getters
    
    public Veterinario getVeterinario() {
        return veterinario;
    }

    public int getId() {
        return id;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public String getMotivo() {
        return motivo;
    }

    public String getEstado() {
        return estado;
    }

    public LocalDateTime getFechaDeCreacion() {
        return fechaDeCreacion;
    }
    
    //Setters

    public void setId(int id) {
        this.id = id;
    }

    public void setMascota(Mascota mascota) {
        this.mascota = mascota;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public void setVeterinario(Veterinario veterinario) {
        this.veterinario = veterinario;
    }

    public void setFechaDeCreacion(LocalDateTime fechaDeCreacion) {
        this.fechaDeCreacion = fechaDeCreacion;
    }
    
    @Override
    public String toString() { 
        String nombreMascota = (mascota != null) ? mascota.getNombre() : "Sin mascota";
        String nombreVet = (veterinario != null) ? veterinario.getNombre(): "Sin veterinario";
        
        return fecha + " " + hora + " | " + nombreMascota + " con " + nombreVet + "[" + estado + "]";
    }   
    
}
