/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hub3.vetcaresystem.model;

import java.time.LocalDateTime;

/**
 *
 * @author coder
 */
public class AtencionMedica {
    
    private int id;
    private Cita cita;
    private String sintomas;
    private String diagnostico;
    private String tratamiento;
    private String observaciones;
    private LocalDateTime fechaDeAtencion;
    private String estado;
    
    public AtencionMedica() { 
        this.fechaDeAtencion = LocalDateTime.now();
    }

    public AtencionMedica(int id, Cita cita,String sintomas, String diagnostico, String tratamiento, String observaciones, LocalDateTime fechaDeAtencion, String estado) {
        this.id = id;
        this.cita = cita;
        this.sintomas = sintomas;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
        this.observaciones = observaciones;
        this.fechaDeAtencion = fechaDeAtencion;
        this.estado = estado;
    }
    
    //Getters

    public int getId() {
        return id;
    }

    public Cita getCita() {
        return cita;
    }

    public String getSintomas() {
        return sintomas;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public String getTratamiento() {
        return tratamiento;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public LocalDateTime getFechaDeAtencion() {
        return fechaDeAtencion;
    }

    public String getEstado() {
        return estado;
    }
    
    //Setters
    
    public void setId(int id) {
        this.id = id;
    }

    public void setCita(Cita cita) {
        this.cita = cita;
    }

    public void setSintomas(String sintomas) {
        this.sintomas = sintomas;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public void setTratamiento(String tratamiento) {
        this.tratamiento = tratamiento;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public void setFechaDeAtencion(LocalDateTime fechaDeAtencion) {
        this.fechaDeAtencion = fechaDeAtencion;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    @Override 
    public String toString() { 
         String Mostrarcita = (this.cita != null) ? this.cita.toString() : "Sin cita";
        
        return Mostrarcita + " - " + cita + " (" + sintomas + ") | Fecha de Atencion: " + fechaDeAtencion + " | Estado: " + estado;
    }
    
    
}
