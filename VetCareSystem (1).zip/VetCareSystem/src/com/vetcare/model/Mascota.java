package com.vetcare.model;

import java.time.LocalDate;

/**
 * =========================================================================
 * CLASE: Mascota
 * =========================================================================
 * Igual que Propietario, esta clase vive en la capa MODEL.
 *
 * Punto clave de esta clase: la LLAVE FORÁNEA (Foreign Key)
 * ------------------------------------------------------------
 * En la base de datos, la tabla "mascotas" tiene una columna
 * "id_propietario" que apunta al id de un registro en "propietarios".
 * Eso es una llave foránea a nivel de SQL.
 *
 * En Java, en lugar de guardar solamente el número "id_propietario",
 * guardamos el OBJETO Propietario completo dentro de Mascota:
 *
 *      private Propietario propietario;
 *
 * ¿Por qué hacemos esto y no solo guardar el int del id?
 * Porque en Programación Orientada a Objetos modelamos el mundo real:
 * una mascota "tiene un" propietario, no solo "tiene el número" de un
 * propietario. Gracias a esto, en el código podemos escribir cosas muy
 * naturales como:
 *
 *      mascota.getPropietario().getNombreCompleto()
 *
 * en vez de tener que ir a buscar manualmente el propietario cada vez
 * que lo necesitamos. Esta relación (una Mascota "contiene" un
 * Propietario) es un ejemplo de COMPOSICIÓN, uno de los pilares que
 * usamos en POO además de la herencia.
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class Mascota {

    // =====================================================================
    // ATRIBUTOS
    // =====================================================================

    private int id;                    // PK autogenerada por PostgreSQL.
    private String nombre;             // Nombre de la mascota. Obligatorio.
    private String especie;            // Ej: "Perro", "Gato", "Ave"...
    private String raza;
    private String sexo;               // Ej: "Macho" / "Hembra".
    private LocalDate fechaNacimiento; // No puede ser posterior a hoy (regla de negocio).
    private double peso;               // Debe ser mayor que cero (regla de negocio).

    // Aquí está la relación con el propietario. En la tabla SQL esto es
    // solo un número (id_propietario), pero en Java es el objeto completo.
    private Propietario propietario;

    private boolean activo;
    private LocalDate fechaRegistro;

    // =====================================================================
    // CONSTRUCTORES
    // =====================================================================

    /** Constructor vacío: necesario para ir llenando el objeto con setters
     *  (por ejemplo, cuando leemos filas desde un ResultSet). */
    public Mascota() {
    }

    /** Constructor sin id: se usa para REGISTRAR una mascota nueva, porque
     *  el id todavía no existe (lo genera la base de datos). */
    public Mascota(String nombre, String especie, String raza, String sexo,
                    LocalDate fechaNacimiento, double peso, Propietario propietario,
                    boolean activo, LocalDate fechaRegistro) {
        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.sexo = sexo;
        this.fechaNacimiento = fechaNacimiento;
        this.peso = peso;
        this.propietario = propietario;
        this.activo = activo;
        this.fechaRegistro = fechaRegistro;
    }

    /** Constructor con id: se usa cuando la mascota YA EXISTE en la base
     *  de datos (por ejemplo, al leerla con un SELECT). */
    public Mascota(int id, String nombre, String especie, String raza, String sexo,
                    LocalDate fechaNacimiento, double peso, Propietario propietario,
                    boolean activo, LocalDate fechaRegistro) {
        this(nombre, especie, raza, sexo, fechaNacimiento, peso, propietario, activo, fechaRegistro);
        this.id = id;
    }

    // =====================================================================
    // GETTERS Y SETTERS
    // =====================================================================

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public Propietario getPropietario() {
        return propietario;
    }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    // =====================================================================
    // toString()
    // =====================================================================

    @Override
    public String toString() {
        // OJO: usamos propietario.getNombreCompleto() para mostrar algo
        // legible en vez del objeto Propietario completo. Por eso es tan
        // útil tener el objeto Propietario embebido: podemos "navegar"
        // hacia sus datos con un simple punto (.).
        String nombrePropietario = (propietario != null) ? propietario.getNombreCompleto() : "SIN PROPIETARIO";
        return "ID: " + id
                + " | Nombre: " + nombre
                + " | Especie: " + especie
                + " | Raza: " + raza
                + " | Sexo: " + sexo
                + " | Peso: " + peso + " kg"
                + " | Propietario: " + nombrePropietario
                + " | Estado: " + (activo ? "ACTIVA" : "INACTIVA");
    }
}
