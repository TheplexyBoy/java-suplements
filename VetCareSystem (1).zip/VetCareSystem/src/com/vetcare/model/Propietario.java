package com.vetcare.model;

import java.time.LocalDate;

/**
 * =========================================================================
 * CLASE: Propietario
 * =========================================================================
 * Esta clase pertenece a la capa MODEL (modelo) de nuestra arquitectura.
 *
 * ¿Qué hace una clase "model"?
 * -----------------------------
 * Es simplemente un "molde" en Java que representa, campo por campo, una
 * fila de la tabla "propietarios" en la base de datos PostgreSQL.
 *
 * Este tipo de clase también se conoce como POJO (Plain Old Java Object) o
 * JavaBean: NO tiene lógica de negocio (no valida nada, no habla con la
 * base de datos), solo GUARDA DATOS y los expone mediante getters/setters.
 *
 * ¿Por qué separamos esto en su propia capa?
 * --------------------------------------------
 * Porque en una arquitectura por capas, cada capa tiene UNA responsabilidad:
 *   - model      -> representar los datos.
 *   - dao        -> hablar con la base de datos.
 *   - service    -> aplicar reglas de negocio (validaciones).
 *   - controller -> coordinar entre la presentación y el service.
 *   - presentation -> mostrar cosas al usuario (JOptionPane).
 *
 * Si mezcláramos todo en una sola clase, cualquier cambio (por ejemplo,
 * cambiar de PostgreSQL a MySQL) obligaría a tocar TODO el programa. Al
 * separar responsabilidades, un cambio en una capa casi no afecta a las
 * demás. Esto se llama "bajo acoplamiento" y es una de las razones por las
 * que la arquitectura por capas es tan usada en el mundo profesional.
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class Propietario {

    // =====================================================================
    // ATRIBUTOS (los mismos campos que tiene la tabla "propietarios" en BD)
    // =====================================================================
    // Los declaramos como "private" (encapsulamiento): nadie desde afuera
    // puede modificar estos valores directamente, deben hacerlo a través de
    // los métodos get/set. Esto nos permite, en el futuro, agregar
    // validaciones dentro de un setter sin romper el resto del programa.

    private int id;                        // Llave primaria (PK) en la BD. Autogenerada por PostgreSQL (SERIAL).
    private String tipoIdentificacion;     // Ej: "CC", "CE", "TI", "PASAPORTE".
    private String numeroIdentificacion;   // Debe ser único según el enunciado del simulacro.
    private String nombreCompleto;         // Campo obligatorio.
    private String telefono;               // Campo obligatorio.
    private String correoElectronico;      // Debe ser único según el enunciado.
    private String direccion;
    private boolean activo;                // Reemplaza el "Estado" del enunciado: true = activo, false = inactivo.
    private LocalDate fechaRegistro;       // Fecha en que el propietario quedó registrado en el sistema.

    // =====================================================================
    // CONSTRUCTORES
    // =====================================================================

    /**
     * Constructor vacío (sin parámetros).
     *
     * ¿Para qué sirve?
     * Muchas herramientas de Java (y nosotros mismos, cuando leemos un
     * ResultSet fila por fila) necesitan poder crear un objeto "vacío" y
     * luego ir llenándolo campo a campo con los setters. Por eso siempre
     * es buena práctica dejar un constructor vacío disponible.
     */
    public Propietario() {
    }

    /**
     * Constructor "completo sin id".
     *
     * ¿Por qué sin id?
     * Cuando vamos a INSERTAR un propietario nuevo, todavía no tiene id:
     * ese número lo genera PostgreSQL automáticamente (columna SERIAL).
     * Por eso este constructor es el que usamos en el flujo de "registrar".
     */
    public Propietario(String tipoIdentificacion, String numeroIdentificacion,
                        String nombreCompleto, String telefono, String correoElectronico,
                        String direccion, boolean activo, LocalDate fechaRegistro) {
        this.tipoIdentificacion = tipoIdentificacion;
        this.numeroIdentificacion = numeroIdentificacion;
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.direccion = direccion;
        this.activo = activo;
        this.fechaRegistro = fechaRegistro;
    }

    /**
     * Constructor "completo con id".
     *
     * Este lo usamos cuando LEEMOS un propietario que YA EXISTE en la base
     * de datos (por ejemplo, al hacer un SELECT), porque ahí sí conocemos
     * su id real.
     */
    public Propietario(int id, String tipoIdentificacion, String numeroIdentificacion,
                        String nombreCompleto, String telefono, String correoElectronico,
                        String direccion, boolean activo, LocalDate fechaRegistro) {
        this(tipoIdentificacion, numeroIdentificacion, nombreCompleto, telefono,
                correoElectronico, direccion, activo, fechaRegistro);
        this.id = id;
    }

    // =====================================================================
    // GETTERS Y SETTERS
    // =====================================================================
    // Son la "puerta de entrada y salida" controlada de cada atributo
    // privado. Aunque parezcan repetitivos, son la base del encapsulamiento
    // en POO: hoy solo devuelven el valor, pero mañana podríamos agregar
    // una validación aquí sin que el resto del programa se entere del
    // cambio interno.

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipoIdentificacion() {
        return tipoIdentificacion;
    }

    public void setTipoIdentificacion(String tipoIdentificacion) {
        this.tipoIdentificacion = tipoIdentificacion;
    }

    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public boolean isActivo() {
        // Nota: para atributos booleanos, la convención de Java es usar
        // "isXxx()" en lugar de "getXxx()". NetBeans lo genera así solo.
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    // =====================================================================
    // toString()
    // =====================================================================

    /**
     * Sobreescribimos (@Override) el método toString() que toda clase Java
     * hereda de Object. ¿Para qué? Porque en la capa de presentación vamos
     * a mostrar listas de propietarios dentro de un JOptionPane, y por
     * defecto Java mostraría algo feo como "Propietario@1a2b3c". Al
     * sobreescribir toString(), controlamos exactamente cómo se ve el
     * objeto cuando lo imprimimos o concatenamos con texto.
     */
    @Override
    public String toString() {
        return "ID: " + id
                + " | " + tipoIdentificacion + " " + numeroIdentificacion
                + " | Nombre: " + nombreCompleto
                + " | Tel: " + telefono
                + " | Correo: " + correoElectronico
                + " | Estado: " + (activo ? "ACTIVO" : "INACTIVO");
    }
}
