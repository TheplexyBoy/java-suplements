package com.vetcare.exception;

/**
 * =========================================================================
 * CLASE: ValidacionException
 * =========================================================================
 * Esta es una EXCEPCIÓN PERSONALIZADA (custom exception).
 *
 * ¿Qué es una excepción?
 * ------------------------
 * Es la forma que tiene Java de decir "algo salió mal" e interrumpir el
 * flujo normal del código para que TÚ decidas cómo manejarlo (mostrar un
 * mensaje, reintentar, cancelar la operación, etc.).
 *
 * ¿Por qué crear nuestra PROPIA excepción en lugar de usar
 * RuntimeException directamente?
 * ------------------------------------------------------------------------
 * Porque así podemos distinguir, en los bloques catch, QUÉ TIPO de error
 * ocurrió:
 *   - ValidacionException   -> el usuario cometió un error de negocio
 *                              (ej: "el correo ya existe", "el peso debe
 *                              ser mayor a cero"). Esto NO es un error de
 *                              programación, es un error esperado y
 *                              controlado.
 *   - PersistenciaException -> algo falló al hablar con la base de datos
 *                              (ej: se cayó la conexión). Esto sí puede
 *                              ser un problema técnico.
 *
 * Al separarlas, en la capa de presentación podemos mostrar mensajes
 * distintos y más claros para el usuario final, dependiendo de qué pasó.
 *
 * ¿Por qué extiende de RuntimeException y no de Exception?
 * ------------------------------------------------------------------------
 * En Java existen excepciones "checked" (heredan de Exception, obligan a
 * poner try/catch o "throws" en la firma del método) y "unchecked"
 * (heredan de RuntimeException, no obligan a manejarlas explícitamente).
 * Elegimos RuntimeException para no llenar TODAS las firmas de métodos de
 * las capas service/controller/dao con "throws ValidacionException", lo
 * cual haría el código más difícil de leer para un principiante. Aun así,
 * SIEMPRE la capturamos explícitamente donde tiene sentido (Controller).
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class ValidacionException extends RuntimeException {

    /**
     * Constructor que recibe el mensaje de error.
     *
     * "super(mensaje)" le pasa ese texto a la clase padre (RuntimeException),
     * que internamente lo guarda para que después, cuando hagamos
     * "excepcion.getMessage()", nos devuelva justamente este texto.
     */
    public ValidacionException(String mensaje) {
        super(mensaje);
    }
}
