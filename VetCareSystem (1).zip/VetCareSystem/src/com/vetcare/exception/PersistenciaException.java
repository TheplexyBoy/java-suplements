package com.vetcare.exception;

/**
 * =========================================================================
 * CLASE: PersistenciaException
 * =========================================================================
 * Excepción personalizada que usamos SOLO en la capa DAO (la que habla
 * directamente con PostgreSQL).
 *
 * ¿Cuándo la lanzamos?
 * -----------------------
 * Cada vez que capturamos un SQLException (el error nativo de JDBC) dentro
 * de un método del DAO, lo "envolvemos" (wrap) dentro de esta excepción
 * propia y la relanzamos.
 *
 * ¿Por qué "envolver" el SQLException en vez de dejarlo pasar tal cual?
 * ------------------------------------------------------------------------
 * 1) Para que las capas superiores (service, controller, presentation)
 *    NO necesiten saber que por debajo estamos usando JDBC/SQL. Si mañana
 *    cambiamos de tecnología de persistencia, solo tocamos el DAO: las
 *    demás capas siguen atrapando "PersistenciaException" sin enterarse
 *    del cambio interno. Esto es el principio de "encapsulamiento entre
 *    capas".
 * 2) Para poder agregar nuestro propio mensaje, más amigable, sin perder
 *    el error técnico original (lo guardamos como "causa").
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class PersistenciaException extends RuntimeException {

    /**
     * Constructor con mensaje y causa original.
     *
     * @param mensaje texto explicativo, pensado para nosotros como
     *                desarrolladores (o para mostrarlo al usuario de forma
     *                controlada).
     * @param causa   la excepción original (normalmente un SQLException).
     *                Al pasarla con "super(mensaje, causa)" NO perdemos el
     *                detalle técnico: sigue disponible si hacemos
     *                "excepcion.getCause()", lo cual es MUY útil para
     *                depurar errores.
     */
    public PersistenciaException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }

    /** Constructor simple, para cuando no hay una causa técnica original. */
    public PersistenciaException(String mensaje) {
        super(mensaje);
    }
}
