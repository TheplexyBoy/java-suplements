package com.vetcare.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * =========================================================================
 * CLASE: ConexionBD
 * =========================================================================
 * Esta clase pertenece a la capa "config" (configuración). Su ÚNICA
 * responsabilidad es saber CÓMO abrir una conexión hacia PostgreSQL.
 *
 * ¿Por qué centralizar la conexión en un solo lugar?
 * ------------------------------------------------------------------------
 * Imagina que tuviéramos el usuario, la contraseña y la URL de la base de
 * datos escritos (hardcodeados) repetidos en cada clase DAO. Si un día
 * cambia la contraseña, tendríamos que buscar y modificar el código en
 * decenas de archivos. Al centralizarlo aquí, solo se cambia UNA VEZ.
 *
 * ¿Qué es el "driver" JDBC?
 * -----------------------------
 * JDBC (Java Database Connectivity) es un estándar: define CÓMO Java debe
 * hablar con cualquier base de datos relacional, pero no sabe hablar con
 * PostgreSQL específicamente. Para eso existe el "driver" de PostgreSQL
 * (el archivo .jar "postgresql-xx.x.jar"), que traduce las órdenes JDBC
 * genéricas al protocolo particular que entiende PostgreSQL. Por eso este
 * proyecto necesita tener ese .jar agregado como librería en NetBeans
 * (ver el README.md para el paso a paso).
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class ConexionBD {

    // =====================================================================
    // DATOS DE CONEXIÓN
    // =====================================================================
    // IMPORTANTE: cambia estos valores según tu instalación local de
    // PostgreSQL. Los detalles de cómo crear la base de datos "vetcare_db"
    // están explicados paso a paso en el README.md del proyecto.

    // URL con el formato: jdbc:postgresql://HOST:PUERTO/NOMBRE_BASE_DE_DATOS
    private static final String URL = "jdbc:postgresql://localhost:5432/vetcare_db";
    private static final String USUARIO = "postgres";
    private static final String PASSWORD = "postgres";

    /**
     * Bloque estático: se ejecuta UNA sola vez, automáticamente, quando la
     * clase ConexionBD se carga en memoria por primera vez (antes de que
     * cualquiera pueda usarla). Aquí "registramos" el driver de PostgreSQL
     * ante el DriverManager de Java, para que sepa que existe.
     *
     * Nota: en versiones modernas de JDBC (4.0+) esto suele hacerse
     * automáticamente, pero lo dejamos explícito porque es MUY didáctico
     * entender que, por debajo, siempre hay un driver registrándose.
     */
    static {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            // Si esto falla, casi siempre es porque el .jar del driver de
            // PostgreSQL no fue agregado como librería del proyecto en
            // NetBeans. Lanzamos un error claro y detenemos la ejecución,
            // porque sin driver el programa NO puede funcionar.
            throw new RuntimeException(
                    "No se encontró el Driver de PostgreSQL. "
                    + "Verifica que el archivo .jar del driver esté agregado "
                    + "en Libraries dentro de NetBeans. Revisa el README.md.", e);
        }
    }

    /**
     * Constructor privado.
     *
     * ¿Por qué privado? Esta clase NO necesita ser instanciada (no tiene
     * sentido crear un "objeto ConexionBD"): solo ofrece un método
     * estático de utilidad. Al hacer el constructor privado, evitamos que
     * alguien escriba "new ConexionBD()" por error. Este patrón se conoce
     * como "clase de utilidad" (utility class).
     */
    private ConexionBD() {
    }

    /**
     * Abre y devuelve una NUEVA conexión a la base de datos cada vez que
     * se llama.
     *
     * ¿Por qué una conexión nueva en cada llamado, y no una sola
     * conexión compartida para todo el programa?
     * ------------------------------------------------------------------
     * Para un proyecto de este tamaño (simulacro/aprendizaje), abrir una
     * conexión nueva por cada operación es simple y suficiente. Además,
     * como vamos a usar "try-with-resources" en cada DAO, la conexión se
     * cierra automáticamente apenas terminamos de usarla, liberando
     * recursos del servidor de base de datos. (En proyectos productivos
     * grandes se usaría un "pool de conexiones", pero eso es un tema más
     * avanzado que se sale del alcance de este simulacro).
     *
     * @return una Connection lista para usar.
     * @throws SQLException si PostgreSQL no está disponible, o si el
     *                       usuario/contraseña/URL están mal configurados.
     */
    public static Connection obtenerConexion() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }
}
