package com.vetcare.presentation;

import com.vetcare.controller.MascotaController;
import com.vetcare.controller.PropietarioController;
import com.vetcare.controller.PropietarioController.Resultado;
import com.vetcare.model.Mascota;
import com.vetcare.model.Propietario;

import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;

/**
 * =========================================================================
 * CLASE: Main
 * =========================================================================
 * Esta es la capa de PRESENTACIÓN. Es la ÚNICA capa que sabe que existe
 * JOptionPane. Ni el Service, ni el Controller, ni el DAO deben conocer
 * NADA sobre interfaces gráficas: esa es la regla de oro de la
 * arquitectura por capas ("no se permitirá ejecutar SQL desde los
 * controladores ni desde los menús", y de forma similar, tampoco se
 * permite lógica de negocio dentro de esta clase).
 *
 * ¿Qué hace esta clase, en resumen?
 * ------------------------------------------------------------------------
 * 1) Le pregunta datos al usuario con JOptionPane.showInputDialog(...).
 * 2) Arma un objeto Propietario o Mascota con esos datos.
 * 3) Se lo entrega al Controller correspondiente.
 * 4) Muestra el resultado (éxito o error) con JOptionPane.showMessageDialog(...).
 *
 * Todo el manejo de errores de negocio o de base de datos YA fue resuelto
 * por el Controller: aquí solo leemos "resultado.isExitoso()" y
 * "resultado.getMensaje()".
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class Main {

    // Instanciamos los controladores UNA sola vez, para reutilizarlos en
    // todo el ciclo de vida del programa.
    private static final PropietarioController propietarioController = new PropietarioController();
    private static final MascotaController mascotaController = new MascotaController();

    // Formato de fecha que le vamos a pedir al usuario, para que sea claro
    // y no ambiguo (dd/MM/yyyy en vez de, por ejemplo, mm/dd/yyyy).
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    /**
     * Punto de entrada del programa. Todo programa Java ejecutable
     * necesita un método "main" con exactamente esta firma.
     */
    public static void main(String[] args) {
        boolean continuar = true;

        // Bucle principal del programa: se repite hasta que el usuario
        // elige "Salir" o cierra el diálogo (lo cual JOptionPane reporta
        // como una respuesta null, que también manejamos como salida).
        while (continuar) {
            String opcion = JOptionPane.showInputDialog(null,
                    "=== VETCARE SYSTEM ===\n"
                    + "Selecciona una opción escribiendo el número:\n\n"
                    + "1. Gestión de Propietarios\n"
                    + "2. Gestión de Mascotas\n"
                    + "3. Salir\n",
                    "Menú Principal", JOptionPane.QUESTION_MESSAGE);

            if (opcion == null) {
                // El usuario cerró la ventana con la "X": interpretamos
                // esto como "quiere salir del programa".
                continuar = false;
            } else {
                switch (opcion.trim()) {
                    case "1":
                        menuPropietarios();
                        break;
                    case "2":
                        menuMascotas();
                        break;
                    case "3":
                        continuar = false;
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción no válida. Intenta de nuevo.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        JOptionPane.showMessageDialog(null, "¡Gracias por usar VetCareSystem!");
        // System.exit(0) cierra explícitamente la JVM. Lo usamos porque
        // JOptionPane, al mostrar diálogos, puede dejar hilos de Swing
        // corriendo en segundo plano que impedirían que el programa
        // termine solo.
        System.exit(0);
    }

    // =========================================================================
    // SUB-MENÚ: PROPIETARIOS
    // =========================================================================

    private static void menuPropietarios() {
        boolean regresar = false;
        while (!regresar) {
            String opcion = JOptionPane.showInputDialog(null,
                    "=== GESTIÓN DE PROPIETARIOS ===\n\n"
                    + "1. Registrar propietario\n"
                    + "2. Listar propietarios\n"
                    + "3. Buscar por identificación\n"
                    + "4. Actualizar propietario\n"
                    + "5. Activar / Desactivar propietario\n"
                    + "6. Ver mascotas de un propietario\n"
                    + "0. Regresar al menú principal\n",
                    "Propietarios", JOptionPane.QUESTION_MESSAGE);

            if (opcion == null || opcion.trim().equals("0")) {
                // Contemplamos también "opcion == null" aquí para "Evitar
                // que el programa se cierre ante una entrada inválida":
                // si el usuario cierra el diálogo, simplemente regresamos
                // al menú anterior en lugar de lanzar una excepción.
                regresar = true;
                continue;
            }

            switch (opcion.trim()) {
                case "1":
                    registrarPropietario();
                    break;
                case "2":
                    listarPropietarios();
                    break;
                case "3":
                    buscarPropietarioPorIdentificacion();
                    break;
                case "4":
                    actualizarPropietario();
                    break;
                case "5":
                    cambiarEstadoPropietario();
                    break;
                case "6":
                    verMascotasDeUnPropietario();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void registrarPropietario() {
        // Pedimos cada dato con un showInputDialog. Si el usuario cancela
        // en cualquier punto, "leerTexto" devuelve null y detenemos el
        // proceso de forma segura (sin lanzar excepciones).
        String tipoId = leerTexto("Tipo de identificación (CC, CE, TI, PASAPORTE):");
        if (tipoId == null) return;

        String numeroId = leerTexto("Número de identificación:");
        if (numeroId == null) return;

        String nombre = leerTexto("Nombre completo:");
        if (nombre == null) return;

        String telefono = leerTexto("Teléfono:");
        if (telefono == null) return;

        String correo = leerTexto("Correo electrónico (opcional, Cancelar para dejar vacío):");
        String direccion = leerTexto("Dirección (opcional, Cancelar para dejar vacío):");

        // Armamos el objeto Propietario. OJO: no seteamos "activo" ni
        // "fechaRegistro" aquí: eso lo decide el Service (regla de
        // negocio: todo propietario nuevo nace activo con la fecha de
        // hoy). La presentación NO debe tomar esas decisiones.
        Propietario nuevo = new Propietario();
        nuevo.setTipoIdentificacion(tipoId);
        nuevo.setNumeroIdentificacion(numeroId);
        nuevo.setNombreCompleto(nombre);
        nuevo.setTelefono(telefono);
        nuevo.setCorreoElectronico(correo);
        nuevo.setDireccion(direccion);

        // Delegamos al Controller y mostramos el resultado. Esta línea es
        // el corazón de la separación de capas: la presentación NO sabe
        // (ni le importa) si el error viene de una validación de negocio
        // o de un fallo de base de datos.
        Resultado<Propietario> resultado = propietarioController.registrar(nuevo);
        mostrarResultado(resultado.isExitoso(), resultado.getMensaje());
    }

    private static void listarPropietarios() {
        Resultado<List<Propietario>> resultado = propietarioController.listarTodos();
        if (!resultado.isExitoso()) {
            mostrarResultado(false, resultado.getMensaje());
            return;
        }

        List<Propietario> lista = resultado.getDato();
        if (lista.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay propietarios registrados todavía.");
            return;
        }

        // Construimos un solo texto con todos los propietarios, uno por
        // línea, usando el toString() que ya definimos en el modelo.
        StringBuilder sb = new StringBuilder("=== LISTADO DE PROPIETARIOS ===\n\n");
        for (Propietario p : lista) {
            sb.append(p.toString()).append("\n");
        }
        // JTextArea dentro de un JOptionPane permite mostrar listas largas
        // con scroll, a diferencia de un simple showMessageDialog de texto.
        mostrarListaConScroll(sb.toString());
    }

    private static void buscarPropietarioPorIdentificacion() {
        String numeroId = leerTexto("Número de identificación a buscar:");
        if (numeroId == null) return;

        Resultado<Propietario> resultado = propietarioController.buscarPorIdentificacion(numeroId);
        if (!resultado.isExitoso()) {
            mostrarResultado(false, resultado.getMensaje());
            return;
        }
        JOptionPane.showMessageDialog(null, "Propietario encontrado:\n\n" + resultado.getDato());
    }

    private static void actualizarPropietario() {
        String numeroId = leerTexto("Número de identificación del propietario a actualizar:");
        if (numeroId == null) return;

        Resultado<Propietario> busqueda = propietarioController.buscarPorIdentificacion(numeroId);
        if (!busqueda.isExitoso()) {
            mostrarResultado(false, busqueda.getMensaje());
            return;
        }

        Propietario existente = busqueda.getDato();

        // Le mostramos el valor actual entre paréntesis y dejamos que el
        // usuario decida si lo cambia o simplemente confirma el mismo.
        String nombre = leerTextoConValorPrevio("Nombre completo:", existente.getNombreCompleto());
        if (nombre == null) return;
        String telefono = leerTextoConValorPrevio("Teléfono:", existente.getTelefono());
        if (telefono == null) return;
        String correo = leerTextoConValorPrevio("Correo electrónico:", existente.getCorreoElectronico());
        String direccion = leerTextoConValorPrevio("Dirección:", existente.getDireccion());

        existente.setNombreCompleto(nombre);
        existente.setTelefono(telefono);
        existente.setCorreoElectronico(correo);
        existente.setDireccion(direccion);

        Resultado<Propietario> resultado = propietarioController.actualizar(existente);
        mostrarResultado(resultado.isExitoso(), resultado.getMensaje());
    }

    private static void cambiarEstadoPropietario() {
        String numeroId = leerTexto("Número de identificación del propietario:");
        if (numeroId == null) return;

        Resultado<Propietario> busqueda = propietarioController.buscarPorIdentificacion(numeroId);
        if (!busqueda.isExitoso()) {
            mostrarResultado(false, busqueda.getMensaje());
            return;
        }

        Propietario existente = busqueda.getDato();
        boolean nuevoEstado = !existente.isActivo(); // invertimos el estado actual.

        // "Mostrar confirmaciones antes de eliminar, cancelar o
        // desactivar" (requisito del enunciado).
        int confirmacion = JOptionPane.showConfirmDialog(null,
                "El propietario está actualmente " + (existente.isActivo() ? "ACTIVO" : "INACTIVO") + ".\n"
                + "¿Deseas cambiarlo a " + (nuevoEstado ? "ACTIVO" : "INACTIVO") + "?",
                "Confirmar cambio de estado", JOptionPane.YES_NO_OPTION);

        if (confirmacion != JOptionPane.YES_OPTION) {
            return; // El usuario canceló: no hacemos nada.
        }

        Resultado<Void> resultado = propietarioController.cambiarEstado(existente.getId(), nuevoEstado);
        mostrarResultado(resultado.isExitoso(), resultado.getMensaje());
    }

    private static void verMascotasDeUnPropietario() {
        String numeroId = leerTexto("Número de identificación del propietario:");
        if (numeroId == null) return;

        Resultado<Propietario> busqueda = propietarioController.buscarPorIdentificacion(numeroId);
        if (!busqueda.isExitoso()) {
            mostrarResultado(false, busqueda.getMensaje());
            return;
        }

        Propietario propietario = busqueda.getDato();
        Resultado<List<Mascota>> resultado = mascotaController.listarPorPropietario(propietario.getId());
        if (!resultado.isExitoso()) {
            mostrarResultado(false, resultado.getMensaje());
            return;
        }

        List<Mascota> mascotas = resultado.getDato();
        if (mascotas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Este propietario todavía no tiene mascotas registradas.");
            return;
        }

        StringBuilder sb = new StringBuilder("=== MASCOTAS DE " + propietario.getNombreCompleto().toUpperCase() + " ===\n\n");
        for (Mascota m : mascotas) {
            sb.append(m.toString()).append("\n");
        }
        mostrarListaConScroll(sb.toString());
    }

    // =========================================================================
    // SUB-MENÚ: MASCOTAS
    // =========================================================================

    private static void menuMascotas() {
        boolean regresar = false;
        while (!regresar) {
            String opcion = JOptionPane.showInputDialog(null,
                    "=== GESTIÓN DE MASCOTAS ===\n\n"
                    + "1. Registrar mascota\n"
                    + "2. Listar todas las mascotas\n"
                    + "3. Buscar mascota por nombre\n"
                    + "4. Actualizar mascota\n"
                    + "5. Activar / Desactivar mascota\n"
                    + "0. Regresar al menú principal\n",
                    "Mascotas", JOptionPane.QUESTION_MESSAGE);

            if (opcion == null || opcion.trim().equals("0")) {
                regresar = true;
                continue;
            }

            switch (opcion.trim()) {
                case "1":
                    registrarMascota();
                    break;
                case "2":
                    listarMascotas();
                    break;
                case "3":
                    buscarMascotaPorNombre();
                    break;
                case "4":
                    actualizarMascota();
                    break;
                case "5":
                    cambiarEstadoMascota();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void registrarMascota() {
        // Primero necesitamos saber A QUÉ propietario pertenece la mascota.
        String numeroIdPropietario = leerTexto("Número de identificación del propietario:");
        if (numeroIdPropietario == null) return;

        Resultado<Propietario> busquedaPropietario = propietarioController.buscarPorIdentificacion(numeroIdPropietario);
        if (!busquedaPropietario.isExitoso()) {
            mostrarResultado(false, busquedaPropietario.getMensaje());
            return;
        }
        Propietario propietario = busquedaPropietario.getDato();

        String nombre = leerTexto("Nombre de la mascota:");
        if (nombre == null) return;

        String especie = leerTexto("Especie (Perro, Gato, Ave, etc.):");
        if (especie == null) return;

        String raza = leerTexto("Raza (opcional, Cancelar para dejar vacío):");
        String sexo = leerTexto("Sexo (Macho / Hembra):");

        // Pedimos la fecha de nacimiento como texto y la convertimos con
        // manejo de errores (el usuario podría escribir un formato
        // incorrecto, y NO queremos que el programa se caiga por eso).
        LocalDate fechaNacimiento = leerFecha("Fecha de nacimiento (dd/MM/yyyy):");
        if (fechaNacimiento == null) return;

        Double peso = leerDecimal("Peso en kilogramos (ej: 12.5):");
        if (peso == null) return;

        Mascota nueva = new Mascota();
        nueva.setNombre(nombre);
        nueva.setEspecie(especie);
        nueva.setRaza(raza);
        nueva.setSexo(sexo);
        nueva.setFechaNacimiento(fechaNacimiento);
        nueva.setPeso(peso);
        // Solo necesitamos asignar el ID del propietario: el Service, al
        // registrar, vuelve a consultar el propietario COMPLETO en la
        // base de datos para garantizar que los datos estén actualizados
        // y que en verdad exista (ver MascotaService.registrar()).
        nueva.setPropietario(propietario);

        Resultado<Mascota> resultado = mascotaController.registrar(nueva);
        mostrarResultado(resultado.isExitoso(), resultado.getMensaje());
    }

    private static void listarMascotas() {
        Resultado<List<Mascota>> resultado = mascotaController.listarTodas();
        if (!resultado.isExitoso()) {
            mostrarResultado(false, resultado.getMensaje());
            return;
        }

        List<Mascota> lista = resultado.getDato();
        if (lista.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay mascotas registradas todavía.");
            return;
        }

        StringBuilder sb = new StringBuilder("=== LISTADO DE MASCOTAS ===\n\n");
        for (Mascota m : lista) {
            sb.append(m.toString()).append("\n");
        }
        mostrarListaConScroll(sb.toString());
    }

    private static void buscarMascotaPorNombre() {
        String nombre = leerTexto("Nombre (o parte del nombre) a buscar:");
        if (nombre == null) return;

        Resultado<List<Mascota>> resultado = mascotaController.buscarPorNombre(nombre);
        if (!resultado.isExitoso()) {
            mostrarResultado(false, resultado.getMensaje());
            return;
        }

        List<Mascota> lista = resultado.getDato();
        if (lista.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se encontraron mascotas con ese nombre.");
            return;
        }

        StringBuilder sb = new StringBuilder("=== RESULTADOS DE LA BÚSQUEDA ===\n\n");
        for (Mascota m : lista) {
            sb.append(m.toString()).append("\n");
        }
        mostrarListaConScroll(sb.toString());
    }

    private static void actualizarMascota() {
        Integer id = leerEntero("ID de la mascota a actualizar:");
        if (id == null) return;

        Optional<Mascota> optMascota = mascotaController.listarTodas().getDato() == null
                ? Optional.empty()
                : mascotaController.listarTodas().getDato().stream()
                        .filter(m -> m.getId() == id)
                        .findFirst();

        if (optMascota.isEmpty()) {
            mostrarResultado(false, "No se encontró ninguna mascota con ese ID.");
            return;
        }

        Mascota existente = optMascota.get();

        String raza = leerTextoConValorPrevio("Raza:", existente.getRaza());
        String sexo = leerTextoConValorPrevio("Sexo:", existente.getSexo());
        Double peso = leerDecimalConValorPrevio("Peso en kilogramos:", existente.getPeso());
        if (peso == null) return;

        existente.setRaza(raza);
        existente.setSexo(sexo);
        existente.setPeso(peso);

        Resultado<Mascota> resultado = mascotaController.actualizar(existente);
        mostrarResultado(resultado.isExitoso(), resultado.getMensaje());
    }

    private static void cambiarEstadoMascota() {
        Integer id = leerEntero("ID de la mascota:");
        if (id == null) return;

        int confirmacion = JOptionPane.showConfirmDialog(null,
                "¿Deseas cambiar el estado (activar/desactivar) de la mascota con ID " + id + "?",
                "Confirmar cambio de estado", JOptionPane.YES_NO_OPTION);

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        // Para saber a qué estado cambiar, primero consultamos el actual.
        List<Mascota> todas = mascotaController.listarTodas().getDato();
        Optional<Mascota> optMascota = todas == null ? Optional.empty()
                : todas.stream().filter(m -> m.getId() == id).findFirst();

        if (optMascota.isEmpty()) {
            mostrarResultado(false, "No se encontró ninguna mascota con ese ID.");
            return;
        }

        boolean nuevoEstado = !optMascota.get().isActivo();
        Resultado<Void> resultado = mascotaController.cambiarEstado(id, nuevoEstado);
        mostrarResultado(resultado.isExitoso(), resultado.getMensaje());
    }

    // =========================================================================
    // MÉTODOS DE APOYO (helpers) PARA LEER DATOS DEL USUARIO DE FORMA SEGURA
    // =========================================================================
    // Estos métodos existen para no repetir, una y otra vez, la misma
    // lógica de "pedir un dato y validar que no venga vacío o mal
    // formado". Centralizar esto aquí también facilita cumplir el
    // requisito de "Evitar que el programa se cierre ante una entrada
    // inválida".

    /** Pide un texto simple. Devuelve null si el usuario cancela (para que el método que llama pueda abortar). */
    private static String leerTexto(String mensaje) {
        String valor = JOptionPane.showInputDialog(null, mensaje);
        // Si el usuario presiona "Cancelar", showInputDialog devuelve null:
        // lo respetamos como "el usuario no quiere continuar".
        return valor;
    }

    /** Igual que leerTexto, pero mostrando el valor actual como sugerencia inicial (útil para actualizar). */
    private static String leerTextoConValorPrevio(String mensaje, String valorActual) {
        return JOptionPane.showInputDialog(null, mensaje, valorActual);
    }

    /**
     * Pide un número entero, validando el formato en un bucle. Si el
     * usuario escribe texto que no es un número, mostramos un error y
     * volvemos a preguntar, EN VEZ de dejar que un NumberFormatException
     * detenga el programa.
     */
    private static Integer leerEntero(String mensaje) {
        while (true) {
            String texto = JOptionPane.showInputDialog(null, mensaje);
            if (texto == null) {
                return null; // el usuario canceló.
            }
            try {
                return Integer.parseInt(texto.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Debes escribir un número entero válido.",
                        "Entrada inválida", JOptionPane.ERROR_MESSAGE);
                // El bucle "while(true)" vuelve a preguntar automáticamente.
            }
        }
    }

    /** Igual que leerEntero, pero para números decimales (usados en el peso). */
    private static Double leerDecimal(String mensaje) {
        while (true) {
            String texto = JOptionPane.showInputDialog(null, mensaje);
            if (texto == null) {
                return null;
            }
            try {
                // Reemplazamos coma por punto por si el usuario, acostumbrado
                // al formato regional, escribe "12,5" en vez de "12.5".
                return Double.parseDouble(texto.trim().replace(",", "."));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Debes escribir un número válido (ej: 12.5).",
                        "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static Double leerDecimalConValorPrevio(String mensaje, double valorActual) {
        while (true) {
            String texto = JOptionPane.showInputDialog(null, mensaje, String.valueOf(valorActual));
            if (texto == null) {
                return null;
            }
            try {
                return Double.parseDouble(texto.trim().replace(",", "."));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Debes escribir un número válido (ej: 12.5).",
                        "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Pide una fecha en formato dd/MM/yyyy, validando el formato en un
     * bucle (igual que con los números). DateTimeParseException es lo que
     * lanza LocalDate.parse(...) cuando el texto no cumple el patrón.
     */
    private static LocalDate leerFecha(String mensaje) {
        while (true) {
            String texto = JOptionPane.showInputDialog(null, mensaje);
            if (texto == null) {
                return null;
            }
            try {
                return LocalDate.parse(texto.trim(), FORMATO_FECHA);
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(null, "Formato de fecha inválido. Usa dd/MM/yyyy (ej: 15/03/2022).",
                        "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /** Muestra un mensaje de éxito o de error, con el ícono correcto según el caso. */
    private static void mostrarResultado(boolean exitoso, String mensaje) {
        if (exitoso) {
            JOptionPane.showMessageDialog(null, mensaje, "Operación exitosa", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Muestra un texto largo (por ejemplo, un listado con muchos
     * registros) dentro de un área con scroll, en vez de un
     * showMessageDialog normal (que se vuelve inmanejable con textos
     * largos). Usamos un JTextArea dentro de un JScrollPane.
     */
    private static void mostrarListaConScroll(String contenido) {
        javax.swing.JTextArea areaTexto = new javax.swing.JTextArea(contenido);
        areaTexto.setEditable(false); // Es solo para mostrar información, no para editarla.
        areaTexto.setLineWrap(true);
        areaTexto.setWrapStyleWord(true);

        javax.swing.JScrollPane panelConScroll = new javax.swing.JScrollPane(areaTexto);
        panelConScroll.setPreferredSize(new java.awt.Dimension(550, 350));

        JOptionPane.showMessageDialog(null, panelConScroll, "Resultado", JOptionPane.PLAIN_MESSAGE);
    }
}
