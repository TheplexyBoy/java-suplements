package com.vetcare.controller;

import com.vetcare.controller.PropietarioController.Resultado;
import com.vetcare.exception.PersistenciaException;
import com.vetcare.exception.ValidacionException;
import com.vetcare.model.Mascota;
import com.vetcare.service.MascotaService;

import java.util.List;
import java.util.Optional;

/**
 * =========================================================================
 * CLASE: MascotaController
 * =========================================================================
 * Mismo rol que PropietarioController, pero para Mascota: recibe las
 * órdenes de la presentación, llama al MascotaService, y traduce
 * cualquier excepción en un objeto Resultado<T> fácil de consumir desde
 * JOptionPane.
 *
 * Nota: reutilizamos la clase interna "Resultado<T>" que definimos dentro
 * de PropietarioController, para no duplicar el mismo código en dos
 * lugares (principio DRY). La importamos con un "import" normal, ya que
 * es una clase interna estática (static nested class) pública.
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class MascotaController {

    private final MascotaService mascotaService;

    public MascotaController() {
        this.mascotaService = new MascotaService();
    }

    /** Registra una mascota nueva. */
    public Resultado<Mascota> registrar(Mascota mascota) {
        try {
            Mascota guardada = mascotaService.registrar(mascota);
            return Resultado.ok("Mascota registrada correctamente con el ID " + guardada.getId() + ".", guardada);

        } catch (ValidacionException e) {
            return Resultado.error(e.getMessage());

        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al guardar en la base de datos. Intenta nuevamente.");

        } catch (Exception e) {
            return Resultado.error("Ocurrió un error inesperado: " + e.getMessage());
        }
    }

    /** Lista todas las mascotas. */
    public Resultado<List<Mascota>> listarTodas() {
        try {
            List<Mascota> lista = mascotaService.listarTodas();
            return Resultado.ok("Consulta realizada correctamente.", lista);
        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al consultar la base de datos.");
        }
    }

    /** Lista las mascotas de un propietario específico (para ver su historial). */
    public Resultado<List<Mascota>> listarPorPropietario(int idPropietario) {
        try {
            List<Mascota> lista = mascotaService.listarPorPropietario(idPropietario);
            return Resultado.ok("Consulta realizada correctamente.", lista);
        } catch (ValidacionException e) {
            return Resultado.error(e.getMessage());
        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al consultar la base de datos.");
        }
    }

    /** Busca mascotas por nombre (coincidencia parcial). */
    public Resultado<List<Mascota>> buscarPorNombre(String nombre) {
        try {
            List<Mascota> lista = mascotaService.buscarPorNombre(nombre);
            return Resultado.ok("Consulta realizada correctamente.", lista);
        } catch (ValidacionException e) {
            return Resultado.error(e.getMessage());
        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al consultar la base de datos.");
        }
    }

    /** Actualiza los datos de una mascota. */
    public Resultado<Mascota> actualizar(Mascota mascota) {
        try {
            Mascota actualizada = mascotaService.actualizar(mascota);
            return Resultado.ok("Mascota actualizada correctamente.", actualizada);
        } catch (ValidacionException e) {
            return Resultado.error(e.getMessage());
        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al actualizar en la base de datos.");
        }
    }

    /** Activa o desactiva una mascota. */
    public Resultado<Void> cambiarEstado(int id, boolean activo) {
        try {
            mascotaService.cambiarEstado(id, activo);
            String accion = activo ? "activada" : "desactivada";
            return Resultado.ok("Mascota " + accion + " correctamente.", null);
        } catch (ValidacionException e) {
            return Resultado.error(e.getMessage());
        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al actualizar el estado en la base de datos.");
        }
    }
}
