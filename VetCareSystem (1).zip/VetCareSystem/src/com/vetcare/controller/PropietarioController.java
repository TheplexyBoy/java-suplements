package com.vetcare.controller;

import com.vetcare.exception.PersistenciaException;
import com.vetcare.exception.ValidacionException;
import com.vetcare.model.Propietario;
import com.vetcare.service.PropietarioService;

import java.util.List;
import java.util.Optional;

/**
 * =========================================================================
 * CLASE: PropietarioController
 * =========================================================================
 * Esta clase pertenece a la capa CONTROLLER. Es el "puente" entre la
 * capa de PRESENTACIÓN (JOptionPane) y la capa SERVICE (reglas de
 * negocio).
 *
 * ¿Por qué necesitamos un Controller si ya tenemos un Service?
 * ------------------------------------------------------------------------
 * Porque queremos que la capa de presentación (Main.java) NO tenga que
 * lidiar con try/catch de excepciones técnicas ni de negocio. El
 * Controller se encarga de:
 *   1) Recibir la "orden" desde la presentación (ej: "registra este
 *      propietario").
 *   2) Llamar al Service correspondiente.
 *   3) ATRAPAR cualquier excepción que ocurra (ValidacionException,
 *      PersistenciaException, o cualquier otra inesperada).
 *   4) Traducir esa excepción en una RESPUESTA simple y entendible
 *      (nuestra clase interna "Resultado"), que la presentación pueda
 *      usar fácilmente con un simple "if (resultado.isExitoso())".
 *
 * De esta forma, JOptionPane.showMessageDialog(...) en Main.java nunca
 * necesita saber si el error vino de una validación de negocio o de un
 * fallo de conexión a la base de datos: solo necesita mostrar el mensaje
 * que el Controller ya le preparó.
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class PropietarioController {

    private final PropietarioService propietarioService;

    public PropietarioController() {
        this.propietarioService = new PropietarioService();
    }

    /**
     * CLASE INTERNA: Resultado
     * -------------------------
     * Es un pequeño "sobre" (wrapper) que agrupa tres cosas:
     *   - si la operación fue exitosa o no,
     *   - un mensaje para mostrarle al usuario,
     *   - y (opcionalmente) el dato resultante, si aplica.
     *
     * ¿Por qué la hacemos "genérica" con <T>?
     * Así la podemos reutilizar tanto para operaciones que devuelven un
     * Propietario, como para operaciones que devuelven una List<Propietario>,
     * o incluso operaciones que no devuelven nada (T = Void).
     */
    public static class Resultado<T> {
        private final boolean exitoso;
        private final String mensaje;
        private final T dato;

        private Resultado(boolean exitoso, String mensaje, T dato) {
            this.exitoso = exitoso;
            this.mensaje = mensaje;
            this.dato = dato;
        }

        public static <T> Resultado<T> ok(String mensaje, T dato) {
            return new Resultado<>(true, mensaje, dato);
        }

        public static <T> Resultado<T> error(String mensaje) {
            return new Resultado<>(false, mensaje, null);
        }

        public boolean isExitoso() {
            return exitoso;
        }

        public String getMensaje() {
            return mensaje;
        }

        public T getDato() {
            return dato;
        }
    }

    /** Registra un propietario nuevo, atrapando cualquier error de negocio o técnico. */
    public Resultado<Propietario> registrar(Propietario propietario) {
        try {
            Propietario guardado = propietarioService.registrar(propietario);
            return Resultado.ok("Propietario registrado correctamente con el ID " + guardado.getId() + ".", guardado);

        } catch (ValidacionException e) {
            // Errores de negocio: el mensaje ya viene listo para mostrarse
            // tal cual al usuario (ej: "El correo ya existe").
            return Resultado.error(e.getMessage());

        } catch (PersistenciaException e) {
            // Errores técnicos (falló la conexión, etc.): mostramos un
            // mensaje genérico y amigable, NO el detalle técnico crudo,
            // para no confundir al usuario final.
            return Resultado.error("Ocurrió un error al guardar en la base de datos. Intenta nuevamente.");

        } catch (Exception e) {
            // Red de seguridad: cualquier otro error no previsto. Nunca
            // dejamos que una excepción "se escape" hasta la interfaz
            // gráfica sin control, porque eso cerraría el programa de
            // forma abrupta y confusa para el usuario.
            return Resultado.error("Ocurrió un error inesperado: " + e.getMessage());
        }
    }

    /** Lista todos los propietarios. */
    public Resultado<List<Propietario>> listarTodos() {
        try {
            List<Propietario> lista = propietarioService.listarTodos();
            return Resultado.ok("Consulta realizada correctamente.", lista);
        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al consultar la base de datos.");
        }
    }

    /** Busca un propietario por número de identificación. */
    public Resultado<Propietario> buscarPorIdentificacion(String numeroIdentificacion) {
        try {
            Optional<Propietario> encontrado = propietarioService.consultarPorIdentificacion(numeroIdentificacion);
            if (encontrado.isPresent()) {
                return Resultado.ok("Propietario encontrado.", encontrado.get());
            }
            return Resultado.error("No se encontró ningún propietario con esa identificación.");
        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al consultar la base de datos.");
        }
    }

    /** Actualiza un propietario existente. */
    public Resultado<Propietario> actualizar(Propietario propietario) {
        try {
            Propietario actualizado = propietarioService.actualizar(propietario);
            return Resultado.ok("Propietario actualizado correctamente.", actualizado);
        } catch (ValidacionException e) {
            return Resultado.error(e.getMessage());
        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al actualizar en la base de datos.");
        }
    }

    /** Activa o desactiva un propietario. */
    public Resultado<Void> cambiarEstado(int id, boolean activo) {
        try {
            propietarioService.cambiarEstado(id, activo);
            String accion = activo ? "activado" : "desactivado";
            return Resultado.ok("Propietario " + accion + " correctamente.", null);
        } catch (ValidacionException e) {
            return Resultado.error(e.getMessage());
        } catch (PersistenciaException e) {
            return Resultado.error("Ocurrió un error al actualizar el estado en la base de datos.");
        }
    }
}
