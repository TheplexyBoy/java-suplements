package com.vetcare.service;

import com.vetcare.dao.PropietarioDAO;
import com.vetcare.dao.impl.PropietarioDAOImpl;
import com.vetcare.exception.ValidacionException;
import com.vetcare.model.Propietario;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * =========================================================================
 * CLASE: PropietarioService
 * =========================================================================
 * Esta clase pertenece a la capa SERVICE. Aquí vive la LÓGICA DE NEGOCIO:
 * todas las reglas que el enunciado del simulacro exige (identificación
 * única, correo único, campos obligatorios, etc.).
 *
 * Diferencia clave entre DAO y SERVICE:
 * ------------------------------------------------------------------------
 * - El DAO sabe "CÓMO guardar" un propietario en PostgreSQL (SQL, JDBC).
 * - El SERVICE sabe "SI SE PUEDE guardar" ese propietario (reglas de
 *   negocio) y, si todo está bien, LE PIDE al DAO que lo guarde.
 *
 * El Service NUNCA debería escribir SQL directamente: siempre delega esa
 * responsabilidad al DAO. Así mantenemos "separadas la presentación, la
 * lógica de negocio y la persistencia", tal como pide el enunciado.
 *
 * Fíjate también que el Service depende de la INTERFAZ PropietarioDAO
 * (no de PropietarioDAOImpl directamente) en la mayoría de sus métodos.
 * Solo en el constructor "sabemos" cuál implementación concreta usar.
 * Esto se llama "inyección de dependencias manual" (sin frameworks como
 * Spring, que sería un tema más avanzado).
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class PropietarioService {

    // El Service "conoce" el contrato (la interfaz), no los detalles
    // internos de JDBC. Esto es la clave del bajo acoplamiento.
    private final PropietarioDAO propietarioDAO;

    /**
     * Constructor: aquí decidimos, en un único lugar de todo el programa,
     * qué implementación concreta del DAO se va a usar. Si mañana
     * quisiéramos cambiar de PostgreSQL a otra tecnología, este es
     * prácticamente el ÚNICO lugar que tocaríamos.
     */
    public PropietarioService() {
        this.propietarioDAO = new PropietarioDAOImpl();
    }

    /**
     * Registra un nuevo propietario, aplicando TODAS las validaciones de
     * negocio del enunciado antes de guardarlo.
     *
     * @throws ValidacionException si alguna regla de negocio no se cumple.
     */
    public Propietario registrar(Propietario propietario) {
        // ---------------------------------------------------------------
        // Validación 1: el nombre y el teléfono son obligatorios.
        // ---------------------------------------------------------------
        // trim() elimina espacios en blanco al inicio/final, así evitamos
        // que un usuario "engañe" la validación escribiendo solo espacios.
        if (propietario.getNombreCompleto() == null || propietario.getNombreCompleto().trim().isEmpty()) {
            throw new ValidacionException("El nombre completo es obligatorio.");
        }
        if (propietario.getTelefono() == null || propietario.getTelefono().trim().isEmpty()) {
            throw new ValidacionException("El teléfono es obligatorio.");
        }
        if (propietario.getNumeroIdentificacion() == null || propietario.getNumeroIdentificacion().trim().isEmpty()) {
            throw new ValidacionException("El número de identificación es obligatorio.");
        }

        // ---------------------------------------------------------------
        // Validación 2: la identificación debe ser única.
        // ---------------------------------------------------------------
        // Le preguntamos al DAO si YA existe un propietario con ese mismo
        // número de identificación. Optional.isPresent() nos dice "sí hay
        // un valor adentro" sin arriesgarnos a un NullPointerException.
        Optional<Propietario> existentePorId = propietarioDAO.buscarPorNumeroIdentificacion(propietario.getNumeroIdentificacion());
        if (existentePorId.isPresent()) {
            throw new ValidacionException("Ya existe un propietario registrado con esa identificación.");
        }

        // ---------------------------------------------------------------
        // Validación 3: el correo electrónico no puede repetirse.
        // ---------------------------------------------------------------
        // Solo validamos si el usuario SÍ escribió un correo (el enunciado
        // no lo marca como obligatorio, solo como "único" si se informa).
        if (propietario.getCorreoElectronico() != null && !propietario.getCorreoElectronico().trim().isEmpty()) {
            boolean correoRepetido = propietarioDAO.listarTodos().stream()
                    .anyMatch(p -> propietario.getCorreoElectronico().equalsIgnoreCase(p.getCorreoElectronico()));
            if (correoRepetido) {
                throw new ValidacionException("Ya existe un propietario registrado con ese correo electrónico.");
            }
        }

        // ---------------------------------------------------------------
        // Si llegamos hasta aquí, todas las validaciones pasaron. Fijamos
        // valores por defecto razonables y delegamos el guardado al DAO.
        // ---------------------------------------------------------------
        propietario.setActivo(true); // Todo propietario nuevo nace activo.
        propietario.setFechaRegistro(LocalDate.now());

        return propietarioDAO.guardar(propietario);
    }

    /** Consulta un propietario por id. Delega directamente al DAO: aquí no hay reglas de negocio que aplicar. */
    public Optional<Propietario> consultarPorId(int id) {
        return propietarioDAO.buscarPorId(id);
    }

    /** Consulta un propietario por su número de identificación. */
    public Optional<Propietario> consultarPorIdentificacion(String numeroIdentificacion) {
        return propietarioDAO.buscarPorNumeroIdentificacion(numeroIdentificacion);
    }

    /** Lista todos los propietarios registrados (activos e inactivos). */
    public List<Propietario> listarTodos() {
        return propietarioDAO.listarTodos();
    }

    /**
     * Actualiza los datos de un propietario existente, revalidando reglas
     * de negocio (por ejemplo: si cambia el correo, que el nuevo correo
     * tampoco esté repetido en OTRO propietario distinto a él mismo).
     */
    public Propietario actualizar(Propietario propietario) {
        // Primero confirmamos que el propietario exista de verdad.
        Propietario existente = propietarioDAO.buscarPorId(propietario.getId())
                .orElseThrow(() -> new ValidacionException("No existe un propietario con el id indicado."));

        if (propietario.getNombreCompleto() == null || propietario.getNombreCompleto().trim().isEmpty()) {
            throw new ValidacionException("El nombre completo es obligatorio.");
        }
        if (propietario.getTelefono() == null || propietario.getTelefono().trim().isEmpty()) {
            throw new ValidacionException("El teléfono es obligatorio.");
        }

        // Verificamos que el correo, SI cambió, no choque con el de OTRO
        // propietario (excluimos al propio "existente" de la comparación).
        if (propietario.getCorreoElectronico() != null && !propietario.getCorreoElectronico().trim().isEmpty()) {
            boolean correoRepetido = propietarioDAO.listarTodos().stream()
                    .filter(p -> p.getId() != propietario.getId())
                    .anyMatch(p -> propietario.getCorreoElectronico().equalsIgnoreCase(p.getCorreoElectronico()));
            if (correoRepetido) {
                throw new ValidacionException("Ya existe OTRO propietario registrado con ese correo electrónico.");
            }
        }

        boolean actualizado = propietarioDAO.actualizar(propietario);
        if (!actualizado) {
            throw new ValidacionException("No fue posible actualizar el propietario.");
        }
        return propietario;
    }

    /**
     * Activa o desactiva un propietario.
     *
     * Regla de negocio relacionada (enunciado): "Un propietario inactivo
     * no podrá registrar nuevas mascotas ni solicitar nuevas citas". Esa
     * parte de la regla la aplicamos del lado de MascotaService, cuando
     * se registra una mascota nueva (ver MascotaService.registrar()).
     */
    public void cambiarEstado(int id, boolean activo) {
        propietarioDAO.buscarPorId(id)
                .orElseThrow(() -> new ValidacionException("No existe un propietario con el id indicado."));
        propietarioDAO.cambiarEstado(id, activo);
    }
}
