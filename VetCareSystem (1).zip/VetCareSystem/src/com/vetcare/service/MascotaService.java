package com.vetcare.service;

import com.vetcare.dao.MascotaDAO;
import com.vetcare.dao.PropietarioDAO;
import com.vetcare.dao.impl.MascotaDAOImpl;
import com.vetcare.dao.impl.PropietarioDAOImpl;
import com.vetcare.exception.ValidacionException;
import com.vetcare.model.Mascota;
import com.vetcare.model.Propietario;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * =========================================================================
 * CLASE: MascotaService
 * =========================================================================
 * Igual que PropietarioService, aquí viven las reglas de negocio de
 * Mascota. Lo interesante de esta clase es que necesita hablar con DOS
 * DAO distintos: MascotaDAO (para las mascotas) y PropietarioDAO (para
 * validar que el propietario exista y esté activo). Esto es normal: un
 * Service puede coordinar varias fuentes de datos relacionadas, siempre
 * que la relación tenga sentido de negocio (como en este caso).
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class MascotaService {

    private final MascotaDAO mascotaDAO;
    private final PropietarioDAO propietarioDAO;

    public MascotaService() {
        this.mascotaDAO = new MascotaDAOImpl();
        this.propietarioDAO = new PropietarioDAOImpl();
    }

    /**
     * Registra una nueva mascota, validando todas las reglas de negocio
     * del enunciado antes de guardarla.
     */
    public Mascota registrar(Mascota mascota) {
        // ---------------------------------------------------------------
        // Validación 1: toda mascota debe pertenecer a un propietario, y
        // ese propietario debe EXISTIR de verdad en la base de datos.
        // ---------------------------------------------------------------
        if (mascota.getPropietario() == null) {
            throw new ValidacionException("La mascota debe tener un propietario asignado.");
        }

        Propietario propietario = propietarioDAO.buscarPorId(mascota.getPropietario().getId())
                .orElseThrow(() -> new ValidacionException("El propietario indicado no existe."));

        // ---------------------------------------------------------------
        // Validación 2: el propietario debe encontrarse ACTIVO.
        // ---------------------------------------------------------------
        // Esta es la regla "Un propietario inactivo no podrá registrar
        // nuevas mascotas" que mencionamos en PropietarioService.
        if (!propietario.isActivo()) {
            throw new ValidacionException("El propietario se encuentra inactivo y no puede registrar nuevas mascotas.");
        }

        // ---------------------------------------------------------------
        // Validación 3: campos obligatorios.
        // ---------------------------------------------------------------
        if (mascota.getNombre() == null || mascota.getNombre().trim().isEmpty()) {
            throw new ValidacionException("El nombre de la mascota es obligatorio.");
        }
        if (mascota.getEspecie() == null || mascota.getEspecie().trim().isEmpty()) {
            throw new ValidacionException("La especie de la mascota es obligatoria.");
        }

        // ---------------------------------------------------------------
        // Validación 4: el peso debe ser mayor que cero.
        // ---------------------------------------------------------------
        if (mascota.getPeso() <= 0) {
            throw new ValidacionException("El peso de la mascota debe ser mayor que cero.");
        }

        // ---------------------------------------------------------------
        // Validación 5: la fecha de nacimiento no puede ser futura.
        // ---------------------------------------------------------------
        if (mascota.getFechaNacimiento() == null) {
            throw new ValidacionException("La fecha de nacimiento es obligatoria.");
        }
        if (mascota.getFechaNacimiento().isAfter(LocalDate.now())) {
            throw new ValidacionException("La fecha de nacimiento no puede ser posterior a la fecha actual.");
        }

        // ---------------------------------------------------------------
        // Validación 6: no repetir la misma mascota (nombre + fecha de
        // nacimiento + propietario) dos veces.
        // ---------------------------------------------------------------
        boolean duplicado = mascotaDAO.existeDuplicado(
                mascota.getNombre(), mascota.getFechaNacimiento(), propietario.getId());
        if (duplicado) {
            throw new ValidacionException(
                    "Ya existe una mascota registrada con ese nombre y fecha de nacimiento para este propietario.");
        }

        // ---------------------------------------------------------------
        // Todo correcto: usamos el propietario COMPLETO que trajimos de
        // la base de datos (no el que llegó a medias desde la
        // presentación, que quizás solo traía el id) y guardamos.
        // ---------------------------------------------------------------
        mascota.setPropietario(propietario);
        mascota.setActivo(true);
        mascota.setFechaRegistro(LocalDate.now());

        return mascotaDAO.guardar(mascota);
    }

    /** Consulta una mascota por id. */
    public Optional<Mascota> consultarPorId(int id) {
        return mascotaDAO.buscarPorId(id);
    }

    /** Lista todas las mascotas registradas. */
    public List<Mascota> listarTodas() {
        return mascotaDAO.listarTodas();
    }

    /** Lista las mascotas asociadas a un propietario específico (historial de mascotas del dueño). */
    public List<Mascota> listarPorPropietario(int idPropietario) {
        propietarioDAO.buscarPorId(idPropietario)
                .orElseThrow(() -> new ValidacionException("El propietario indicado no existe."));
        return mascotaDAO.listarPorPropietario(idPropietario);
    }

    /** Busca mascotas cuyo nombre coincida (parcialmente) con el texto dado. */
    public List<Mascota> buscarPorNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new ValidacionException("Debes indicar un texto para buscar.");
        }
        return mascotaDAO.buscarPorNombre(nombre);
    }

    /** Actualiza los datos de una mascota existente. */
    public Mascota actualizar(Mascota mascota) {
        mascotaDAO.buscarPorId(mascota.getId())
                .orElseThrow(() -> new ValidacionException("No existe una mascota con el id indicado."));

        if (mascota.getPeso() <= 0) {
            throw new ValidacionException("El peso de la mascota debe ser mayor que cero.");
        }
        if (mascota.getFechaNacimiento() != null && mascota.getFechaNacimiento().isAfter(LocalDate.now())) {
            throw new ValidacionException("La fecha de nacimiento no puede ser posterior a la fecha actual.");
        }

        boolean actualizado = mascotaDAO.actualizar(mascota);
        if (!actualizado) {
            throw new ValidacionException("No fue posible actualizar la mascota.");
        }
        return mascota;
    }

    /** Activa o desactiva una mascota. */
    public void cambiarEstado(int id, boolean activo) {
        mascotaDAO.buscarPorId(id)
                .orElseThrow(() -> new ValidacionException("No existe una mascota con el id indicado."));
        mascotaDAO.cambiarEstado(id, activo);
    }
}
