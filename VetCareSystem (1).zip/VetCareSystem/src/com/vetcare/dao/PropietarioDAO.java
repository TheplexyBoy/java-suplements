package com.vetcare.dao;

import com.vetcare.model.Propietario;
import java.util.List;
import java.util.Optional;

/**
 * =========================================================================
 * INTERFAZ: PropietarioDAO
 * =========================================================================
 * "DAO" significa Data Access Object (Objeto de Acceso a Datos).
 *
 * ¿Qué es una interfaz en Java y por qué la usamos aquí?
 * ------------------------------------------------------------------------
 * Una interfaz es un CONTRATO: define QUÉ métodos debe tener una clase,
 * pero NO CÓMO se implementan. Es como un "menú de restaurante": el menú
 * dice qué platos existen, pero no explica la receta.
 *
 * ¿Por qué es tan importante esto en la arquitectura por capas?
 * ------------------------------------------------------------------------
 * La capa SERVICE (que veremos más adelante) va a depender de esta
 * INTERFAZ, no de la clase concreta "PropietarioDAOImpl". Esto se llama
 * "programar contra interfaces, no contra implementaciones", y tiene una
 * ventaja enorme: si mañana quisiéramos cambiar de PostgreSQL a MySQL, o
 * incluso guardar los datos en un archivo de texto, bastaría con crear
 * OTRA clase que implemente esta misma interfaz (ej: "PropietarioDAOMySQL")
 * y el Service seguiría funcionando SIN CAMBIAR NI UNA LÍNEA, porque solo
 * conoce el contrato, no los detalles técnicos internos.
 *
 * @author Andrés Felipe Quintero Hernández
 */
public interface PropietarioDAO {

    /**
     * Inserta un nuevo propietario en la base de datos.
     * @param propietario el objeto a guardar (sin id, porque lo genera la BD).
     * @return el mismo objeto, pero con el id ya asignado por PostgreSQL.
     */
    Propietario guardar(Propietario propietario);

    /**
     * Busca un propietario por su id (llave primaria).
     *
     * ¿Por qué el tipo de retorno es Optional<Propietario> y no
     * simplemente Propietario?
     * ------------------------------------------------------------------
     * Porque es perfectamente normal que un id NO exista en la base de
     * datos (por ejemplo, si el usuario se equivocó al escribirlo).
     * Optional nos OBLIGA, de forma explícita, a pensar en ese caso: en
     * vez de arriesgarnos a un NullPointerException si olvidamos validar
     * "if (propietario != null)", Java nos hace preguntar
     * "optional.isPresent()" antes de usar el valor. Es una práctica
     * moderna y muy recomendada en Java 8+.
     */
    Optional<Propietario> buscarPorId(int id);

    /**
     * Busca un propietario por su número de identificación (regla de
     * negocio: debe ser único, así que como máximo hay un resultado).
     */
    Optional<Propietario> buscarPorNumeroIdentificacion(String numeroIdentificacion);

    /**
     * Retorna TODOS los propietarios registrados (activos e inactivos),
     * para que la capa de presentación decida cómo mostrarlos.
     */
    List<Propietario> listarTodos();

    /**
     * Actualiza los datos de un propietario ya existente (identificado
     * por su id).
     * @return true si se actualizó algún registro, false si el id no existía.
     */
    boolean actualizar(Propietario propietario);

    /**
     * Cambia el estado "activo" de un propietario (activar/desactivar).
     * Preferimos esto a un DELETE físico: en sistemas reales casi nunca se
     * borran registros de verdad (podrían tener historial asociado, como
     * mascotas). Esto se llama "borrado lógico" (soft delete).
     * @return true si se actualizó algún registro, false si el id no existía.
     */
    boolean cambiarEstado(int id, boolean activo);
}
