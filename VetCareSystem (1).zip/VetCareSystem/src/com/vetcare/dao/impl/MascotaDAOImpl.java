package com.vetcare.dao.impl;

import com.vetcare.config.ConexionBD;
import com.vetcare.dao.MascotaDAO;
import com.vetcare.exception.PersistenciaException;
import com.vetcare.model.Mascota;
import com.vetcare.model.Propietario;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * =========================================================================
 * CLASE: MascotaDAOImpl
 * =========================================================================
 * Implementación JDBC del contrato MascotaDAO.
 *
 * El punto más importante de esta clase, comparado con PropietarioDAOImpl,
 * es cómo resolvemos la LLAVE FORÁNEA (id_propietario) al leer datos:
 * usamos un JOIN en el SQL para traer, en una sola consulta, tanto los
 * datos de la mascota COMO los datos de su propietario. Así evitamos
 * hacer una segunda consulta a la base de datos por cada mascota (lo cual
 * sería muy ineficiente, un problema conocido como "N+1 queries").
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class MascotaDAOImpl implements MascotaDAO {

    // Consulta base reutilizable: trae TODAS las columnas de "mascotas"
    // (alias "m") y las columnas de "propietarios" (alias "p") que
    // necesitamos para reconstruir el objeto Propietario embebido.
    // "INNER JOIN" significa: solo trae mascotas que SÍ tengan un
    // propietario asociado que exista (lo cual siempre debería cumplirse,
    // gracias a la restricción FOREIGN KEY que pusimos en el schema.sql).
    private static final String SELECT_BASE =
            "SELECT m.id AS m_id, m.nombre AS m_nombre, m.especie AS m_especie, "
            + "m.raza AS m_raza, m.sexo AS m_sexo, m.fecha_nacimiento AS m_fecha_nacimiento, "
            + "m.peso AS m_peso, m.activo AS m_activo, m.fecha_registro AS m_fecha_registro, "
            + "p.id AS p_id, p.tipo_identificacion AS p_tipo_identificacion, "
            + "p.numero_identificacion AS p_numero_identificacion, p.nombre_completo AS p_nombre_completo, "
            + "p.telefono AS p_telefono, p.correo_electronico AS p_correo_electronico, "
            + "p.direccion AS p_direccion, p.activo AS p_activo, p.fecha_registro AS p_fecha_registro "
            + "FROM mascotas m INNER JOIN propietarios p ON m.id_propietario = p.id";

    @Override
    public Mascota guardar(Mascota mascota) {
        String sql = "INSERT INTO mascotas "
                + "(nombre, especie, raza, sexo, fecha_nacimiento, peso, id_propietario, activo, fecha_registro) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, mascota.getNombre());
            stmt.setString(2, mascota.getEspecie());
            stmt.setString(3, mascota.getRaza());
            stmt.setString(4, mascota.getSexo());
            stmt.setDate(5, Date.valueOf(mascota.getFechaNacimiento()));
            stmt.setDouble(6, mascota.getPeso());
            // OJO: aquí solo guardamos el ID del propietario (m.getPropietario().getId()),
            // porque en la tabla SQL la relación es solo un número entero.
            stmt.setInt(7, mascota.getPropietario().getId());
            stmt.setBoolean(8, mascota.isActivo());
            stmt.setDate(9, Date.valueOf(
                    mascota.getFechaRegistro() != null ? mascota.getFechaRegistro() : LocalDate.now()));

            stmt.executeUpdate();

            try (ResultSet llaves = stmt.getGeneratedKeys()) {
                if (llaves.next()) {
                    mascota.setId(llaves.getInt(1));
                }
            }
            return mascota;

        } catch (SQLException e) {
            throw new PersistenciaException("Error al guardar la mascota en la base de datos.", e);
        }
    }

    @Override
    public Optional<Mascota> buscarPorId(int id) {
        String sql = SELECT_BASE + " WHERE m.id = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearFila(rs));
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al buscar la mascota por id.", e);
        }
        return Optional.empty();
    }

    @Override
    public List<Mascota> listarTodas() {
        String sql = SELECT_BASE + " ORDER BY m.nombre";
        List<Mascota> lista = new ArrayList<>();

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearFila(rs));
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al listar las mascotas.", e);
        }
        return lista;
    }

    @Override
    public List<Mascota> listarPorPropietario(int idPropietario) {
        String sql = SELECT_BASE + " WHERE p.id = ? ORDER BY m.nombre";
        List<Mascota> lista = new ArrayList<>();

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, idPropietario);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearFila(rs));
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al listar las mascotas del propietario.", e);
        }
        return lista;
    }

    @Override
    public List<Mascota> buscarPorNombre(String nombre) {
        // "ILIKE" es específico de PostgreSQL: es como "LIKE" pero
        // ignorando mayúsculas/minúsculas. Los símbolos "%" alrededor del
        // parámetro significan "que contenga este texto en cualquier
        // parte", no que sea exactamente igual.
        String sql = SELECT_BASE + " WHERE m.nombre ILIKE ? ORDER BY m.nombre";
        List<Mascota> lista = new ArrayList<>();

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, "%" + nombre + "%");

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearFila(rs));
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al buscar mascotas por nombre.", e);
        }
        return lista;
    }

    @Override
    public boolean existeDuplicado(String nombre, LocalDate fechaNacimiento, int idPropietario) {
        // Consulta de solo verificación: no necesitamos el JOIN completo
        // aquí, nos basta con contar coincidencias en la tabla "mascotas".
        String sql = "SELECT COUNT(*) FROM mascotas "
                + "WHERE nombre = ? AND fecha_nacimiento = ? AND id_propietario = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setDate(2, Date.valueOf(fechaNacimiento));
            stmt.setInt(3, idPropietario);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Si el conteo es mayor a 0, ya existe un duplicado.
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al verificar duplicados de mascota.", e);
        }
        return false;
    }

    @Override
    public boolean actualizar(Mascota mascota) {
        String sql = "UPDATE mascotas SET nombre = ?, especie = ?, raza = ?, sexo = ?, "
                + "fecha_nacimiento = ?, peso = ?, id_propietario = ? WHERE id = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, mascota.getNombre());
            stmt.setString(2, mascota.getEspecie());
            stmt.setString(3, mascota.getRaza());
            stmt.setString(4, mascota.getSexo());
            stmt.setDate(5, Date.valueOf(mascota.getFechaNacimiento()));
            stmt.setDouble(6, mascota.getPeso());
            stmt.setInt(7, mascota.getPropietario().getId());
            stmt.setInt(8, mascota.getId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new PersistenciaException("Error al actualizar la mascota.", e);
        }
    }

    @Override
    public boolean cambiarEstado(int id, boolean activo) {
        String sql = "UPDATE mascotas SET activo = ? WHERE id = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setBoolean(1, activo);
            stmt.setInt(2, id);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new PersistenciaException("Error al cambiar el estado de la mascota.", e);
        }
    }

    /**
     * Convierte UNA fila del ResultSet (que ya trae, gracias al JOIN,
     * columnas de "mascotas" Y de "propietarios") en un objeto Mascota
     * completo, CON su Propietario embebido armado también.
     *
     * Fíjate que usamos los alias que definimos en SELECT_BASE (m_id,
     * p_id, etc.) para no confundir la columna "id" de mascotas con la
     * columna "id" de propietarios, ya que ambas tablas tienen una
     * columna llamada igual.
     */
    private Mascota mapearFila(ResultSet rs) throws SQLException {
        // Primero armamos el Propietario (la parte "de adentro").
        Propietario propietario = new Propietario();
        propietario.setId(rs.getInt("p_id"));
        propietario.setTipoIdentificacion(rs.getString("p_tipo_identificacion"));
        propietario.setNumeroIdentificacion(rs.getString("p_numero_identificacion"));
        propietario.setNombreCompleto(rs.getString("p_nombre_completo"));
        propietario.setTelefono(rs.getString("p_telefono"));
        propietario.setCorreoElectronico(rs.getString("p_correo_electronico"));
        propietario.setDireccion(rs.getString("p_direccion"));
        propietario.setActivo(rs.getBoolean("p_activo"));
        Date fechaRegistroProp = rs.getDate("p_fecha_registro");
        if (fechaRegistroProp != null) {
            propietario.setFechaRegistro(fechaRegistroProp.toLocalDate());
        }

        // Luego armamos la Mascota (la parte "de afuera") y le insertamos
        // el Propietario que acabamos de construir.
        Mascota mascota = new Mascota();
        mascota.setId(rs.getInt("m_id"));
        mascota.setNombre(rs.getString("m_nombre"));
        mascota.setEspecie(rs.getString("m_especie"));
        mascota.setRaza(rs.getString("m_raza"));
        mascota.setSexo(rs.getString("m_sexo"));
        Date fechaNacimiento = rs.getDate("m_fecha_nacimiento");
        if (fechaNacimiento != null) {
            mascota.setFechaNacimiento(fechaNacimiento.toLocalDate());
        }
        mascota.setPeso(rs.getDouble("m_peso"));
        mascota.setActivo(rs.getBoolean("m_activo"));
        Date fechaRegistroMascota = rs.getDate("m_fecha_registro");
        if (fechaRegistroMascota != null) {
            mascota.setFechaRegistro(fechaRegistroMascota.toLocalDate());
        }
        mascota.setPropietario(propietario);

        return mascota;
    }
}
