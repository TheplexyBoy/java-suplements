package com.vetcare.dao.impl;

import com.vetcare.config.ConexionBD;
import com.vetcare.dao.PropietarioDAO;
import com.vetcare.exception.PersistenciaException;
import com.vetcare.model.Propietario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * =========================================================================
 * CLASE: PropietarioDAOImpl
 * =========================================================================
 * Esta es la IMPLEMENTACIÓN concreta del contrato "PropietarioDAO" usando
 * JDBC puro contra PostgreSQL. Aquí SÍ hay código SQL.
 *
 * "implements PropietarioDAO" significa: "prometo cumplir con TODOS los
 * métodos que la interfaz PropietarioDAO exige". Si olvidamos implementar
 * alguno, el proyecto ni siquiera compila. Eso es justamente la fuerza de
 * las interfaces: garantizan que el contrato se respete.
 *
 * Conceptos de JDBC que vas a ver una y otra vez en esta clase:
 * ------------------------------------------------------------------------
 * - Connection: representa la conexión abierta hacia la base de datos.
 * - PreparedStatement: representa una sentencia SQL "parametrizada", es
 *   decir, con espacios reservados (signos "?") que se rellenan después de
 *   forma segura. SIEMPRE preferimos esto sobre concatenar Strings a mano,
 *   porque:
 *     1) Previene inyección SQL (un usuario malicioso no puede "inyectar"
 *        código SQL a través de un campo de texto).
 *     2) JDBC se encarga de poner comillas, escapar caracteres especiales,
 *        convertir tipos de datos, etc. automáticamente.
 * - ResultSet: representa la TABLA de resultados que devuelve un SELECT.
 *   Se recorre fila por fila con result.next().
 * - try-with-resources: es un try(...) donde declaramos los recursos
 *   (Connection, PreparedStatement, ResultSet) dentro del paréntesis. Java
 *   garantiza que se cierren automáticamente al salir del bloque, EN
 *   ORDEN INVERSO a como se abrieron, incluso si ocurre una excepción.
 *   Esto evita fugas de conexiones (una de las causas más comunes de que
 *   una aplicación se "cuelgue" con el tiempo).
 *
 * @author Andrés Felipe Quintero Hernández
 */
public class PropietarioDAOImpl implements PropietarioDAO {

    @Override
    public Propietario guardar(Propietario p) {
        // Sentencia SQL con "?" como marcadores de posición. El orden de
        // los "?" debe coincidir EXACTAMENTE con el orden en que después
        // llamamos a stmt.setXxx(indice, valor).
        String sql = "INSERT INTO propietarios "
                + "(tipo_identificacion, numero_identificacion, nombre_completo, telefono, "
                + "correo_electronico, direccion, activo, fecha_registro) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        // try-with-resources: abrimos Connection y PreparedStatement aquí.
        // El segundo argumento de prepareStatement (Statement.RETURN_GENERATED_KEYS)
        // le pide a PostgreSQL que nos devuelva el id autogenerado por el SERIAL,
        // porque lo necesitamos para completar el objeto "p" en Java.
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Rellenamos cada "?" en orden. El índice arranca en 1 (no en 0).
            stmt.setString(1, p.getTipoIdentificacion());
            stmt.setString(2, p.getNumeroIdentificacion());
            stmt.setString(3, p.getNombreCompleto());
            stmt.setString(4, p.getTelefono());
            stmt.setString(5, p.getCorreoElectronico());
            stmt.setString(6, p.getDireccion());
            stmt.setBoolean(7, p.isActivo());
            // java.sql.Date.valueOf(...) convierte un LocalDate de Java 8+
            // al tipo de fecha que JDBC entiende.
            stmt.setDate(8, java.sql.Date.valueOf(
                    p.getFechaRegistro() != null ? p.getFechaRegistro() : LocalDate.now()));

            // executeUpdate() se usa para INSERT/UPDATE/DELETE (sentencias
            // que MODIFICAN datos, no que los consultan). Devuelve cuántas
            // filas fueron afectadas.
            stmt.executeUpdate();

            // Recuperamos el id que PostgreSQL generó automáticamente.
            try (ResultSet llaves = stmt.getGeneratedKeys()) {
                if (llaves.next()) {
                    p.setId(llaves.getInt(1));
                }
            }
            return p;

        } catch (SQLException e) {
            // Nunca dejamos "escapar" un SQLException hacia las capas
            // superiores: lo envolvemos en nuestra excepción propia para
            // que el resto del programa no dependa de detalles de JDBC.
            throw new PersistenciaException("Error al guardar el propietario en la base de datos.", e);
        }
    }

    @Override
    public Optional<Propietario> buscarPorId(int id) {
        String sql = "SELECT * FROM propietarios WHERE id = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);

            // executeQuery() se usa SOLO para SELECT (sentencias que
            // consultan datos). Devuelve un ResultSet.
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Encontramos una fila: la convertimos a objeto Java.
                    return Optional.of(mapearFila(rs));
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al buscar el propietario por id.", e);
        }
        // Si no entramos al "if (rs.next())", significa que no hay ninguna
        // fila con ese id: devolvemos un Optional "vacío" en vez de null.
        return Optional.empty();
    }

    @Override
    public Optional<Propietario> buscarPorNumeroIdentificacion(String numeroIdentificacion) {
        String sql = "SELECT * FROM propietarios WHERE numero_identificacion = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, numeroIdentificacion);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearFila(rs));
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al buscar el propietario por número de identificación.", e);
        }
        return Optional.empty();
    }

    @Override
    public List<Propietario> listarTodos() {
        String sql = "SELECT * FROM propietarios ORDER BY nombre_completo";
        List<Propietario> lista = new ArrayList<>();

        // Aquí no hay parámetros "?", así que podríamos usar un Statement
        // normal, pero mantenemos PreparedStatement por CONSISTENCIA en
        // todo el DAO (buena práctica: un mismo estilo en toda la clase).
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            // Recorremos el ResultSet fila por fila. rs.next() avanza el
            // "cursor" una fila y devuelve false cuando ya no hay más.
            while (rs.next()) {
                lista.add(mapearFila(rs));
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al listar los propietarios.", e);
        }
        return lista;
    }

    @Override
    public boolean actualizar(Propietario p) {
        String sql = "UPDATE propietarios SET tipo_identificacion = ?, numero_identificacion = ?, "
                + "nombre_completo = ?, telefono = ?, correo_electronico = ?, direccion = ? "
                + "WHERE id = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, p.getTipoIdentificacion());
            stmt.setString(2, p.getNumeroIdentificacion());
            stmt.setString(3, p.getNombreCompleto());
            stmt.setString(4, p.getTelefono());
            stmt.setString(5, p.getCorreoElectronico());
            stmt.setString(6, p.getDireccion());
            stmt.setInt(7, p.getId());

            // executeUpdate() devuelve el número de FILAS afectadas. Si es
            // 0, quiere decir que ningún registro tenía ese id.
            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            throw new PersistenciaException("Error al actualizar el propietario.", e);
        }
    }

    @Override
    public boolean cambiarEstado(int id, boolean activo) {
        String sql = "UPDATE propietarios SET activo = ? WHERE id = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setBoolean(1, activo);
            stmt.setInt(2, id);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new PersistenciaException("Error al cambiar el estado del propietario.", e);
        }
    }

    /**
     * Método privado de apoyo (helper).
     *
     * ¿Para qué sirve?
     * Convierte UNA fila del ResultSet (posicionado por rs.next()) en un
     * objeto Propietario de Java. Lo extraemos a su propio método porque
     * lo necesitamos en VARIOS lugares de esta clase (buscarPorId,
     * buscarPorNumeroIdentificacion, listarTodos...), y así evitamos
     * repetir el mismo código una y otra vez (principio DRY: "Don't
     * Repeat Yourself").
     */
    private Propietario mapearFila(ResultSet rs) throws SQLException {
        Propietario p = new Propietario();
        p.setId(rs.getInt("id"));
        p.setTipoIdentificacion(rs.getString("tipo_identificacion"));
        p.setNumeroIdentificacion(rs.getString("numero_identificacion"));
        p.setNombreCompleto(rs.getString("nombre_completo"));
        p.setTelefono(rs.getString("telefono"));
        p.setCorreoElectronico(rs.getString("correo_electronico"));
        p.setDireccion(rs.getString("direccion"));
        p.setActivo(rs.getBoolean("activo"));

        // rs.getDate(...) devuelve un java.sql.Date; lo convertimos a
        // LocalDate (la clase moderna de fechas de Java) con .toLocalDate().
        java.sql.Date fecha = rs.getDate("fecha_registro");
        if (fecha != null) {
            p.setFechaRegistro(fecha.toLocalDate());
        }
        return p;
    }
}
