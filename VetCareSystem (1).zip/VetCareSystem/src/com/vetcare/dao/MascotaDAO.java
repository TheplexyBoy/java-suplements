package com.vetcare.dao;

import com.vetcare.model.Mascota;
import java.util.List;
import java.util.Optional;

/**
 * =========================================================================
 * INTERFAZ: MascotaDAO
 * =========================================================================
 * Mismo concepto explicado en PropietarioDAO: este es el CONTRATO que
 * define qué operaciones de persistencia existen para Mascota, sin decir
 * cómo se implementan.
 *
 * @author Andrés Felipe Quintero Hernández
 */
public interface MascotaDAO {

    /** Inserta una nueva mascota (ya debe traer un Propietario válido asignado). */
    Mascota guardar(Mascota mascota);

    /** Busca una mascota por su id, trayendo también su Propietario asociado. */
    Optional<Mascota> buscarPorId(int id);

    /** Retorna todas las mascotas registradas, con su Propietario ya "armado" dentro. */
    List<Mascota> listarTodas();

    /** Retorna únicamente las mascotas de un propietario específico. */
    List<Mascota> listarPorPropietario(int idPropietario);

    /** Busca mascotas cuyo nombre contenga el texto dado (búsqueda parcial, no exacta). */
    List<Mascota> buscarPorNombre(String nombre);

    /**
     * Verifica si YA existe una mascota con el mismo nombre, misma fecha de
     * nacimiento y mismo propietario (regla de negocio: evitar duplicados).
     */
    boolean existeDuplicado(String nombre, java.time.LocalDate fechaNacimiento, int idPropietario);

    /** Actualiza los datos de una mascota existente. */
    boolean actualizar(Mascota mascota);

    /** Activa o desactiva una mascota (borrado lógico). */
    boolean cambiarEstado(int id, boolean activo);
}
