-- =============================================================================
-- SCRIPT: schema.sql
-- Proyecto: VetCareSystem
-- Autor: Andrés Felipe Quintero Hernández
-- =============================================================================
-- Este script crea la base de datos y las dos tablas que usa este simulacro:
-- "propietarios" y "mascotas". Ejecuta estos pasos EN ORDEN desde pgAdmin o
-- psql. Instrucciones detalladas en el README.md.
-- =============================================================================

-- 1) Crea la base de datos (ejecuta esta línea conectado a la BD "postgres").
-- Si ya la creaste, omite esta línea.
CREATE DATABASE vetcare_db;

-- 2) A partir de aquí, conéctate YA a la base de datos "vetcare_db" antes de
--    seguir ejecutando (en pgAdmin: haz clic en vetcare_db antes de correr
--    el resto de este script).

-- =============================================================================
-- TABLA: propietarios
-- =============================================================================
CREATE TABLE propietarios (
    id                      SERIAL PRIMARY KEY,       -- Autoincremental: PostgreSQL genera el ID solo.
    tipo_identificacion     VARCHAR(20)  NOT NULL,
    numero_identificacion   VARCHAR(30)  NOT NULL UNIQUE, -- UNIQUE = no se puede repetir (regla de negocio).
    nombre_completo         VARCHAR(150) NOT NULL,
    telefono                VARCHAR(30)  NOT NULL,
    correo_electronico      VARCHAR(150) UNIQUE,          -- UNIQUE = no se puede repetir.
    direccion               VARCHAR(200),
    activo                  BOOLEAN      NOT NULL DEFAULT TRUE,
    fecha_registro          DATE         NOT NULL DEFAULT CURRENT_DATE
);

-- =============================================================================
-- TABLA: mascotas
-- =============================================================================
CREATE TABLE mascotas (
    id                  SERIAL PRIMARY KEY,
    nombre              VARCHAR(100) NOT NULL,
    especie             VARCHAR(50)  NOT NULL,
    raza                VARCHAR(80),
    sexo                VARCHAR(20),
    fecha_nacimiento    DATE,
    peso                NUMERIC(6,2) NOT NULL CHECK (peso > 0), -- CHECK: PostgreSQL rechaza pesos <= 0.
    id_propietario      INTEGER      NOT NULL,
    activo              BOOLEAN      NOT NULL DEFAULT TRUE,
    fecha_registro      DATE         NOT NULL DEFAULT CURRENT_DATE,

    -- Esta línea es la LLAVE FORÁNEA (Foreign Key) a nivel de base de datos:
    -- le dice a PostgreSQL "id_propietario debe existir en propietarios.id".
    -- Si intentas borrar un propietario que tiene mascotas, PostgreSQL lo
    -- impedirá automáticamente (integridad referencial).
    CONSTRAINT fk_mascota_propietario
        FOREIGN KEY (id_propietario)
        REFERENCES propietarios (id)
);

-- =============================================================================
-- (Opcional) Datos de ejemplo para probar la aplicación rápidamente.
-- =============================================================================
INSERT INTO propietarios (tipo_identificacion, numero_identificacion, nombre_completo, telefono, correo_electronico, direccion)
VALUES ('CC', '1001234567', 'Laura Gómez Restrepo', '3001234567', 'laura.gomez@example.com', 'Calle 10 # 20-30');

INSERT INTO mascotas (nombre, especie, raza, sexo, fecha_nacimiento, peso, id_propietario)
VALUES ('Toby', 'Perro', 'Labrador', 'Macho', '2021-05-14', 24.50, 1);
